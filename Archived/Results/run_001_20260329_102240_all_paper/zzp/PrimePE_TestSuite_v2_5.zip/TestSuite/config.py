# TestSuite/config.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. Central config for all test suite runs.
# ──────────────────────────────────────────────────────────────────────────────

import os
import torch

# ── Paths ─────────────────────────────────────────────────────────────────────
# Edit this to point at your checkpoint directory
CHECKPOINT_DIR = r"C:\Files\Models\CosySim\PrimePE\checkpoints"

# Results saved here — auto-numbered, never overwritten
RESULTS_DIR = os.path.join(os.path.dirname(__file__), "results")

# Zeta zeros cache (generated once by mpmath, reused)
ZETA_ZEROS_CACHE = os.path.join(os.path.dirname(__file__), "zeta_zeros_1000.json")

# WikiText-103 token cache (generated once, reused)
TOKEN_CACHE_DIR = os.path.join(os.path.dirname(__file__), "token_cache")

# ── Device ────────────────────────────────────────────────────────────────────
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
DTYPE  = torch.bfloat16 if torch.cuda.is_available() and \
         torch.cuda.get_device_capability()[0] >= 8 else torch.float16

# ── ZZP Config ────────────────────────────────────────────────────────────────
ZZP_CONFIG = {
    "n_zeros":    1000,      # how many zeta zeros to use
    "seq_len":    50,        # predict next gap from this many previous gaps
    "epochs":     400,       # default epochs (can override via CLI)
    "lr":         1e-3,
    "batch_size": 32,
    "train_split": 0.8,

    # Model config (identical across all 3 variants)
    "d_model":   64,
    "n_heads":   4,
    "n_layers":  3,
    "n_primes":  32,         # primes used in harmonic resonance matrix

    # Which models to run
    "variants": [
        "geometric_rope",
        "spectral_alibi",
        "harmonic_string",
    ],
}

# ── PE Eval Config ────────────────────────────────────────────────────────────
PE_EVAL_CONFIG = {
    # Context lengths to evaluate at
    "eval_ctx_lens": [512, 1024, 2048, 4096, 8192],

    # Batches per context length eval (more = more accurate, slower)
    "eval_batches": 80,

    # Which checkpoint names to look for
    "checkpoint_names": [
        "ckpt_spectral_rope_alibi.pt",
        "ckpt_harmonic_string_alibi.pt",
        "ckpt_harmonic_string.pt",
        "ckpt_spectral_rope.pt",
        "ckpt_alibi.pt",
        "ckpt_rope.pt",
    ],

    # PE name mapping (checkpoint stem -> PE variant name)
    "ckpt_to_pe": {
        "ckpt_spectral_rope_alibi":   "spectral_rope_alibi",
        "ckpt_harmonic_string_alibi": "harmonic_string_alibi",
        "ckpt_harmonic_string":       "harmonic_string",
        "ckpt_spectral_rope":         "spectral_rope",
        "ckpt_alibi":                 "alibi",
        "ckpt_rope":                  "rope",
    },

    # G4 model config (300M params — matches saved checkpoints)
    "model_cfg": {
        "d_model":    768,
        "n_heads":    12,
        "n_layers":   24,
        "ffn_dim":    3072,
        "dropout":    0.1,
        "vocab_size": 50257,
        "train_seq_len": 4096,
        "max_steps":  20000,
    },
}

# ── Mini Training Config (optional, --train flag) ─────────────────────────────
# Runs a small training experiment from scratch on your desktop GPU
# Uses T4 profile: smaller model, shorter context, fewer steps
MINI_TRAIN_CONFIG = {
    "d_model":       256,
    "n_heads":       8,
    "n_layers":      6,
    "ffn_dim":       1024,
    "dropout":       0.1,
    "vocab_size":    50257,
    "train_seq_len": 1024,
    "max_steps":     5000,
    "batch_size":    1,
    "grad_accum":    16,
    "lr":            3e-4,
    "warmup_steps":  500,
    "eval_every":    250,
    "variants": [
        "rope",
        "spectral_rope_alibi",
        "alibi",
    ],
}

# ── Plot Style ────────────────────────────────────────────────────────────────
PLOT_STYLE = {
    "bg":     "#0d1117",
    "grid":   "#1e2a3a",
    "cyan":   "#00b4d8",
    "pink":   "#ff79c6",
    "white":  "#f8f8f2",
    "grey":   "#6272a4",
    "gold":   "#f1fa8c",
    "yellow": "#ffb86c",
    "dpi":    150,
}

# Colour and style per PE variant
PE_STYLES = {
    "spectral_rope_alibi":   {"color": "#00b4d8", "lw": 2.8, "ls": "-",  "label": "SpectralRoPEALiBi (ours)"},
    "harmonic_string_alibi": {"color": "#50fa7b", "lw": 2.2, "ls": "-",  "label": "HarmonicStringALiBi (ours)"},
    "harmonic_string":       {"color": "#f1fa8c", "lw": 2.0, "ls": "-",  "label": "HarmonicString (ours)"},
    "spectral_rope":         {"color": "#f8f8f2", "lw": 2.0, "ls": "-",  "label": "SpectralRoPE (ours)"},
    "alibi":                 {"color": "#ff79c6", "lw": 2.0, "ls": "--", "label": "ALiBi"},
    "rope":                  {"color": "#6272a4", "lw": 1.5, "ls": "--", "label": "RoPE"},
    "geometric_rope":        {"color": "#6272a4", "lw": 1.5, "ls": "--", "label": "GeometricRoPE"},
    "spectral_alibi":        {"color": "#00b4d8", "lw": 2.8, "ls": "-",  "label": "SpectralALiBi (ours)"},
}
