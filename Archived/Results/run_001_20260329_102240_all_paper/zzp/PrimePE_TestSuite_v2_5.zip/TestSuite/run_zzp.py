#!/usr/bin/env python3
# TestSuite/run_zzp.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. CLI entry point for ZetaZeroPredictor experiment.
#
# Usage:
#   python run_zzp.py                    # default 400 epochs
#   python run_zzp.py --epochs 100       # quick test
#   python run_zzp.py --epochs 10000     # long run
#   python run_zzp.py --variants spectral_alibi harmonic_string  # subset
# ──────────────────────────────────────────────────────────────────────────────

import argparse
import os
import sys
import time

import torch

# ── Path setup ────────────────────────────────────────────────────────────────
SUITE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SUITE_DIR)

from config import ZZP_CONFIG, DEVICE, DTYPE, RESULTS_DIR, ZETA_ZEROS_CACHE
from shared.utils import setup_run_dir, setup_logger, save_json, print_banner, gpu_info
from shared.plots import (plot_zzp_convergence, plot_zzp_predictions,
                           plot_zzp_gap_distribution)
from zzp.data import load_zeros, compute_gaps, make_loaders
from zzp.models import make_model, param_count
from zzp.train import train_zzp
from zzp.eval import evaluate_all, get_predictions, compile_results, print_report


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="PrimePE — ZetaZeroPredictor Test Suite",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--epochs",   type=int,   default=ZZP_CONFIG["epochs"],
                   help=f"Training epochs (default: {ZZP_CONFIG['epochs']})")
    p.add_argument("--variants", nargs="+",  default=ZZP_CONFIG["variants"],
                   choices=["geometric_rope", "spectral_alibi", "harmonic_string"],
                   help="Which models to train (default: all three)")
    p.add_argument("--lr",       type=float, default=ZZP_CONFIG["lr"],
                   help=f"Learning rate (default: {ZZP_CONFIG['lr']})")
    p.add_argument("--n-zeros",  type=int,   default=ZZP_CONFIG["n_zeros"],
                   help=f"Number of zeta zeros to use (default: {ZZP_CONFIG['n_zeros']})")
    p.add_argument("--no-save",  action="store_true",
                   help="Skip saving model checkpoints")
    p.add_argument("--print-every", type=int, default=25,
                   help="Log every N epochs (default: 25)")
    return p.parse_args()


def main() -> None:
    args = parse_args()

    # ── Setup run directory ───────────────────────────────────────────────────
    run_dir = setup_run_dir(RESULTS_DIR, prefix="zzp")
    zzp_dir = os.path.join(run_dir, "zzp")
    os.makedirs(zzp_dir, exist_ok=True)

    log = setup_logger(run_dir, "primePE.zzp")

    print_banner("ZETA-ZERO PREDICTOR — PrimePE TestSuite")
    log.info("Run directory: %s", run_dir)
    log.info("Device: %s | VRAM: %s", DEVICE, gpu_info())

    # ── Merge config with CLI args ────────────────────────────────────────────
    cfg = dict(ZZP_CONFIG)
    cfg["epochs"]   = args.epochs
    cfg["variants"] = args.variants
    cfg["lr"]       = args.lr
    cfg["n_zeros"]  = args.n_zeros

    log.info("Variants: %s | Epochs: %d | LR: %.0e",
             cfg["variants"], cfg["epochs"], cfg["lr"])

    # ── Load data ─────────────────────────────────────────────────────────────
    print_banner("Loading Zeta Zeros")
    zeros = load_zeros(ZETA_ZEROS_CACHE, cfg["n_zeros"])
    gaps  = compute_gaps(zeros)

    # Plot gap distribution
    plot_zzp_gap_distribution(
        gaps,
        os.path.join(zzp_dir, "gap_distribution.png"))
    log.info("Gap distribution plot saved.")

    train_loader, val_loader, gap_mean, gap_std = make_loaders(
        zeros,
        seq_len    = cfg["seq_len"],
        batch_size = cfg["batch_size"],
        train_split= cfg["train_split"],
    )

    # ── Build models ──────────────────────────────────────────────────────────
    print_banner("Building Models")
    models = {}
    for name in cfg["variants"]:
        m = make_model(name, cfg).to(DEVICE)
        models[name] = m
        log.info("  %-22s %10d params", name, param_count(m))

    # ── Train ─────────────────────────────────────────────────────────────────
    print_banner(f"Training — {cfg['epochs']} epochs")
    t0      = time.time()
    history = train_zzp(
        models      = models,
        train_loader= train_loader,
        val_loader  = val_loader,
        epochs      = cfg["epochs"],
        lr          = cfg["lr"],
        device      = DEVICE,
        print_every = args.print_every,
    )
    elapsed = time.time() - t0
    log.info("Training complete in %.0f seconds", elapsed)

    # ── Evaluate ──────────────────────────────────────────────────────────────
    print_banner("Evaluation")
    final_mse = evaluate_all(models, val_loader, DEVICE)
    pred_data = get_predictions(models, val_loader, DEVICE)

    # ── Save models ───────────────────────────────────────────────────────────
    if not args.no_save:
        for name, model in models.items():
            ckpt_path = os.path.join(zzp_dir, f"model_{name}.pt")
            torch.save(model.state_dict(), ckpt_path)
            log.info("Saved: %s", ckpt_path)

    # ── Compile and save results ──────────────────────────────────────────────
    results = compile_results(history, final_mse, gap_mean, gap_std,
                               cfg["epochs"], cfg)
    results["elapsed_seconds"] = round(elapsed, 1)
    save_json(results, os.path.join(zzp_dir, "results.json"))

    # Also save raw history for plotting/analysis
    save_json(history, os.path.join(zzp_dir, "history.json"))

    # ── Generate plots ────────────────────────────────────────────────────────
    print_banner("Generating Plots")

    plot_zzp_convergence(
        history,
        os.path.join(zzp_dir, "convergence.png"))
    log.info("Convergence plot saved.")

    preds_by_model = {
        name: pred_data[name][0] for name in models
    }
    actuals = list(pred_data.values())[0][1]
    plot_zzp_predictions(
        actuals, preds_by_model, gap_mean, gap_std,
        os.path.join(zzp_dir, "predictions.png"))
    log.info("Predictions plot saved.")

    # ── Print report ──────────────────────────────────────────────────────────
    print_report(results)

    print()
    log.info("All results saved to: %s", zzp_dir)
    log.info("Key files:")
    log.info("  results.json       — summary statistics")
    log.info("  history.json       — full per-epoch train/val MSE")
    log.info("  convergence.png    — training curves")
    log.info("  predictions.png    — actual vs predicted gaps")
    log.info("  gap_distribution.png — zeta zero gap histogram")


if __name__ == "__main__":
    main()
