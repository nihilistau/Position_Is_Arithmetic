# TestSuite/shared/utils.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. Run directory creation, logging, JSON helpers.
# ──────────────────────────────────────────────────────────────────────────────

from __future__ import annotations
import os
import sys
import json
import logging
import datetime
from pathlib import Path
from typing import Any

import torch


def setup_run_dir(base_results_dir: str, prefix: str = "") -> str:
    """
    Create a unique numbered run directory.
    Format: results/run_NNN_YYYYMMDD_HHMMSS[_prefix]/
    Never overwrites an existing run.

    Args:
        base_results_dir: Root results directory.
        prefix: Optional label appended to run name.

    Returns:
        Absolute path to new run directory.
    """
    os.makedirs(base_results_dir, exist_ok=True)

    # Find next available run number
    existing = [
        d for d in os.listdir(base_results_dir)
        if os.path.isdir(os.path.join(base_results_dir, d))
        and d.startswith("run_")
    ]
    nums = []
    for d in existing:
        try:
            nums.append(int(d.split("_")[1]))
        except (IndexError, ValueError):
            pass
    next_num = max(nums, default=0) + 1

    ts     = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    suffix = f"_{prefix}" if prefix else ""
    name   = f"run_{next_num:03d}_{ts}{suffix}"
    path   = os.path.join(base_results_dir, name)
    os.makedirs(path, exist_ok=True)
    return path


def setup_logger(run_dir: str, name: str = "primePE") -> logging.Logger:
    """Create a logger that writes to both console and run_dir/run.log."""
    log_path = os.path.join(run_dir, "run.log")
    logger   = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s",
                             datefmt="%H:%M:%S")

    # Console handler
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    # File handler
    fh = logging.FileHandler(log_path, encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    return logger


def save_json(data: Any, path: str) -> None:
    """Save data as indented JSON. Creates parent dirs."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=_json_default)


def load_json(path: str) -> Any:
    """Load JSON from path."""
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _json_default(obj: Any) -> Any:
    """JSON serialiser for numpy/torch types."""
    if hasattr(obj, "item"):
        return obj.item()
    if hasattr(obj, "tolist"):
        return obj.tolist()
    raise TypeError(f"Not serialisable: {type(obj)}")


def gpu_info() -> dict:
    """Return GPU memory stats."""
    if not torch.cuda.is_available():
        return {"device": "cpu"}
    props = torch.cuda.get_device_properties(0)
    return {
        "device":    props.name,
        "vram_gb":   round(props.total_memory / 1e9, 1),
        "vram_used": round(torch.cuda.memory_allocated() / 1e9, 2),
    }


def print_banner(title: str) -> None:
    """Print a section banner to stdout."""
    w = 70
    print()
    print("─" * w)
    print(f"  {title}")
    print("─" * w)


def format_table(headers: list[str], rows: list[list[str]],
                 col_widths: list[int] | None = None) -> str:
    """Format a simple ASCII table for console output."""
    if col_widths is None:
        col_widths = [max(len(str(r[i])) for r in [headers] + rows) + 2
                      for i in range(len(headers))]
    lines = []
    hdr = "  ".join(str(h).ljust(w) for h, w in zip(headers, col_widths))
    sep = "  ".join("-" * w for w in col_widths)
    lines.append(hdr)
    lines.append(sep)
    for row in rows:
        lines.append("  ".join(str(c).ljust(w) for c, w in zip(row, col_widths)))
    return "\n".join(lines)
