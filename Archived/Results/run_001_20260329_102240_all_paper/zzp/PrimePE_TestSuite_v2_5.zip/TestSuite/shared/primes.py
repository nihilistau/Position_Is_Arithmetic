# TestSuite/shared/primes.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. Prime utilities, harmonic resonance matrix, spectral freqs.
# ──────────────────────────────────────────────────────────────────────────────

from __future__ import annotations
import math
import functools
import torch


def get_primes(n: int) -> list[int]:
    """Return the first n primes using a simple sieve."""
    primes: list[int] = []
    candidate = 2
    while len(primes) < n:
        if all(candidate % p != 0 for p in primes):
            primes.append(candidate)
        candidate += 1
    return primes


def is_prime(n: int) -> bool:
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    return all(n % i != 0 for i in range(3, int(n ** 0.5) + 1, 2))


def next_prime(n: int) -> int:
    """Return the smallest prime > n."""
    candidate = n + 1
    while not is_prime(candidate):
        candidate += 1
    return candidate


@functools.lru_cache(maxsize=16)
def harmonic_resonance_matrix(T: int, n_primes: int = 64) -> torch.Tensor:
    """
    Precompute R[i,j] = sum_p cos(2*pi*(i-j)/p) / p, normalised so R[0,0]=1.

    Cached by (T, n_primes). First call is slow; all subsequent calls are O(1).

    Primorials get highest resonance (all small harmonics sync simultaneously).
    Prime distances get negative resonance (maximally desynchronised).

    Args:
        T: Sequence length.
        n_primes: Number of primes to include in the sum.

    Returns:
        (T, T) float32 tensor in [-1, 1].
    """
    primes = get_primes(n_primes)
    pos    = torch.arange(T, dtype=torch.float64)
    delta  = pos.unsqueeze(1) - pos.unsqueeze(0)  # (T, T)
    R      = torch.zeros(T, T, dtype=torch.float64)
    for p in primes:
        R += torch.cos(2 * math.pi * delta / p) / p
    r0 = sum(1.0 / p for p in primes)
    return (R / r0).float()


def spectral_rope_freqs(d_model: int, n_heads: int) -> torch.Tensor:
    """
    Build tiered per-head prime frequency tensor for SpectralRoPE.

    Tiers:
      Local    heads 0..n_local:        p=2..101,   8 slots/head
      Mid      heads n_local..n_mid:    p=101..1009, 28 slots/head
      Long     heads n_mid..:           p=1009..8209, 50 slots/head

    Returns:
        (n_heads, rope_half) float32 tensor of frequencies 2*pi/p.
    """
    rope_half = (d_model // n_heads) // 2
    n_local   = max(1, n_heads // 4)
    n_mid     = max(1, n_heads // 3)
    n_long    = max(1, n_heads - n_local - n_mid)

    tiers = [
        (0,       n_local,           2,    101,  max(4, rope_half // 4)),
        (n_local, n_local + n_mid,   101,  1009, rope_half),
        (n_local + n_mid, n_heads,   1009, 8209, max(rope_half, rope_half * 2)),
    ]

    def _next_unused_prime(n: int, used: set[int]) -> int:
        p = max(2, int(n))
        if p % 2 == 0:
            p += 1
        while not is_prime(p) or p in used:
            p += 2
        return p

    rows = []
    for h_start, h_end, p_min, p_max, slots in tiers:
        n_t = max(1, h_end - h_start)
        # Log-spaced target positions
        targets = [p_min * (p_max / p_min) ** (i / max(n_t * slots - 1, 1))
                   for i in range(n_t * slots)]
        used: set[int] = set()
        primes_flat: list[int] = []
        for tgt in targets:
            p = _next_unused_prime(tgt, used)
            used.add(p)
            primes_flat.append(p)

        for i, h in enumerate(range(h_start, h_end)):
            hp = primes_flat[i * slots:(i + 1) * slots]
            # Trim or pad to rope_half
            if len(hp) > rope_half:
                idx = [int(j * (len(hp) - 1) / max(rope_half - 1, 1))
                       for j in range(rope_half)]
                hp = [hp[j] for j in idx]
            while len(hp) < rope_half:
                p = _next_unused_prime(hp[-1] + 2, used)
                used.add(p)
                hp.append(p)
            rows.append(torch.tensor([2 * math.pi / p for p in hp],
                                     dtype=torch.float32))
    return torch.stack(rows)  # (n_heads, rope_half)


def resonance_values_table() -> list[dict]:
    """
    Return a table of R(delta)/R(0) values for selected distances.
    Used in reports.
    """
    primes = get_primes(64)
    r0 = sum(1.0 / p for p in primes)

    def R(delta: int) -> float:
        return sum(math.cos(2 * math.pi * delta / p) / p
                   for p in primes) / r0

    items = [
        (0,    "—",        "Maximum resonance — self"),
        (2,    "prime",    ""),
        (6,    "primorial","2×3"),
        (7,    "prime",    ""),
        (17,   "prime",    "Most negative tested"),
        (30,   "primorial","2×3×5"),
        (42,   "—",        "2×3×7"),
        (210,  "primorial","2×3×5×7 — highest tested"),
        (2310, "primorial","2×3×5×7×11"),
    ]
    return [
        {"delta": d, "R": round(R(d), 4), "type": t, "note": n}
        for d, t, n in items
    ]
