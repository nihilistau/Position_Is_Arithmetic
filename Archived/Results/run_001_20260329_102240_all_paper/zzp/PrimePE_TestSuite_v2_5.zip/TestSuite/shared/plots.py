# TestSuite/shared/plots.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. All plot generation. Consistent dark style across all tests.
# ──────────────────────────────────────────────────────────────────────────────

from __future__ import annotations
import os
import math
import matplotlib
matplotlib.use("Agg")  # headless — no display needed
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np

from config import PLOT_STYLE, PE_STYLES

# ── Apply global matplotlib style ─────────────────────────────────────────────
BG   = PLOT_STYLE["bg"]
GRID = PLOT_STYLE["grid"]
DPI  = PLOT_STYLE["dpi"]

plt.rcParams.update({
    "figure.facecolor":  BG,
    "axes.facecolor":    BG,
    "axes.edgecolor":    GRID,
    "grid.color":        GRID,
    "text.color":        PLOT_STYLE["white"],
    "axes.labelcolor":   PLOT_STYLE["white"],
    "xtick.color":       PLOT_STYLE["white"],
    "ytick.color":       PLOT_STYLE["white"],
    "legend.facecolor":  "#1e2a3a",
    "legend.edgecolor":  GRID,
    "font.family":       "DejaVu Sans",
})


def _style(pe_name: str) -> dict:
    return PE_STYLES.get(pe_name, {"color": "#888888", "lw": 1.5, "ls": "-",
                                    "label": pe_name})


def _save(fig: plt.Figure, path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fig.savefig(path, dpi=DPI, facecolor=BG, bbox_inches="tight")
    plt.close(fig)


# ── ZZP Plots ─────────────────────────────────────────────────────────────────

def plot_zzp_convergence(history: dict[str, list[float]], out_path: str) -> None:
    """
    Plot ZZP training/validation MSE convergence.

    Args:
        history: {"model_name": {"train": [...], "val": [...]}} per model.
        out_path: Where to save the PNG.
    """
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    fig.suptitle("Zeta-Zero Gap Predictor — Convergence",
                 fontsize=13, color=PLOT_STYLE["cyan"])

    for ax, key, title in zip(axes, ["train", "val"],
                               ["Train MSE (log)", "Val MSE (log)"]):
        for name, data in history.items():
            s = _style(name)
            vals = data.get(key, [])
            if not vals:
                continue
            ax.semilogy(vals, label=s["label"], color=s["color"],
                        linewidth=s["lw"], linestyle=s["ls"], alpha=0.9)
        ax.set_title(title, fontsize=11)
        ax.set_xlabel("Epoch", fontsize=10)
        ax.set_ylabel("MSE", fontsize=10)
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)

    plt.tight_layout()
    _save(fig, out_path)


def plot_zzp_predictions(actuals: list[float], preds_by_model: dict[str, list[float]],
                          gap_mean: float, gap_std: float, out_path: str) -> None:
    """
    Plot actual vs predicted gap values for each model.
    """
    n = len(preds_by_model)
    fig, axes = plt.subplots(n, 1, figsize=(12, 4 * n))
    if n == 1:
        axes = [axes]

    act_d = [a * gap_std + gap_mean for a in actuals[:100]]

    for ax, (name, preds) in zip(axes, preds_by_model.items()):
        s = _style(name)
        pred_d = [p * gap_std + gap_mean for p in preds[:100]]
        corr   = float(np.corrcoef(pred_d, act_d)[0, 1])
        ax.plot(act_d, label="Actual", alpha=0.7, color=PLOT_STYLE["grey"])
        ax.plot(pred_d, label=f"Predicted (r={corr:.4f})",
                alpha=0.8, color=s["color"], linestyle="--")
        ax.set_title(s["label"], fontsize=11)
        ax.set_xlabel("Sample")
        ax.set_ylabel("Gap size")
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)

    plt.tight_layout()
    _save(fig, out_path)


def plot_zzp_gap_distribution(gaps: list[float], out_path: str) -> None:
    """Histogram of inter-zero gap distribution."""
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    axes[0].plot(gaps[:100], alpha=0.8, color=PLOT_STYLE["cyan"])
    axes[0].set_title("First 100 inter-zero gaps")
    axes[0].set_xlabel("Index")
    axes[0].set_ylabel("Gap size")
    axes[0].grid(True, alpha=0.3)

    axes[1].hist(gaps, bins=40, alpha=0.8, color=PLOT_STYLE["cyan"],
                 edgecolor=BG)
    axes[1].set_title("Gap distribution (GUE statistics)")
    axes[1].set_xlabel("Gap size")
    axes[1].grid(True, alpha=0.3)

    fig.suptitle("Zeta Zero Gap Distribution", color=PLOT_STYLE["cyan"])
    plt.tight_layout()
    _save(fig, out_path)


# ── PE Eval Plots ──────────────────────────────────────────────────────────────

def plot_ppl_vs_context(ppl_results: dict[str, dict], out_path: str,
                        train_ctx: int | None = None) -> None:
    """
    Plot PPL vs context length on a log x-axis.

    Args:
        ppl_results: {"pe_name": {512: 105.8, 1024: 124.2, ...}}
        train_ctx: If provided, draw a vertical line at training context.
        out_path: Where to save PNG.
    """
    fig, ax = plt.subplots(figsize=(11, 5.5))

    ctx_vals = sorted({int(k) for d in ppl_results.values() for k in d})

    for name, d in ppl_results.items():
        s = _style(name)
        x = [k for k in ctx_vals if k in d or str(k) in d]
        y = [d.get(k, d.get(str(k))) for k in x]
        if not x:
            continue
        ax.plot(x, y, label=s["label"], color=s["color"],
                linewidth=s["lw"], linestyle=s["ls"],
                marker="o", markersize=5, alpha=0.95)
        ax.annotate(f"{y[-1]:.1f}", xy=(x[-1], y[-1]),
                    xytext=(x[-1] * 1.05, y[-1]),
                    color=s["color"], fontsize=8, va="center")

    if train_ctx:
        ax.axvline(x=train_ctx, color=PLOT_STYLE["gold"], alpha=0.4,
                   linewidth=1, linestyle=":")
        ax.text(train_ctx * 1.03, ax.get_ylim()[1] * 0.95,
                "Train ctx", color=PLOT_STYLE["gold"], fontsize=8, alpha=0.7)

    ax.set_xscale("log")
    ctx_labels = {512: "512", 1024: "1K", 2048: "2K", 4096: "4K",
                  8192: "8K", 16384: "16K"}
    ax.set_xticks(ctx_vals)
    ax.set_xticklabels([ctx_labels.get(v, str(v)) for v in ctx_vals])
    ax.set_xlabel("Context Length (tokens)", fontsize=11)
    ax.set_ylabel("Perplexity", fontsize=11)
    ax.set_title("PPL vs Context Length", fontsize=13,
                 color=PLOT_STYLE["cyan"])
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    _save(fig, out_path)


def plot_convergence(training_history: dict[str, dict], out_path: str) -> None:
    """
    Plot training convergence (val loss or PPL over steps).

    Args:
        training_history: {"pe_name": {"steps": [...], "val_ppl": [...]}}
    """
    fig, ax = plt.subplots(figsize=(12, 5.5))

    for name, data in training_history.items():
        s     = _style(name)
        steps = data.get("steps", [])
        ppls  = data.get("val_ppl", [])
        if not steps:
            continue
        ax.plot(steps, ppls, label=s["label"], color=s["color"],
                linewidth=s["lw"], linestyle=s["ls"], alpha=0.95)
        if ppls:
            ax.annotate(f"{ppls[-1]:.1f}", xy=(steps[-1], ppls[-1]),
                        xytext=(steps[-1] * 1.01, ppls[-1]),
                        color=s["color"], fontsize=8, va="center")

    ax.set_xlabel("Training Step", fontsize=11)
    ax.set_ylabel("Validation PPL", fontsize=11)
    ax.set_title("Convergence — All PE Variants", fontsize=13,
                 color=PLOT_STYLE["cyan"])
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    _save(fig, out_path)


def plot_gap_analysis(training_history: dict[str, dict], out_path: str,
                      pairs: list[tuple[str, str]] | None = None) -> None:
    """
    Plot PPL gap between prime PE variants and their baselines.

    Args:
        training_history: {"pe_name": {"steps": [...], "val_ppl": [...]}}
        pairs: [(novel, baseline), ...]. Default: [(SRA, alibi), (SR, rope)]
    """
    if pairs is None:
        pairs = [
            ("spectral_rope_alibi", "alibi"),
            ("spectral_rope",       "rope"),
        ]

    valid_pairs = [(n, b) for n, b in pairs
                   if n in training_history and b in training_history]
    if not valid_pairs:
        return

    fig, axes = plt.subplots(1, len(valid_pairs),
                              figsize=(7 * len(valid_pairs), 5))
    if len(valid_pairs) == 1:
        axes = [axes]

    for ax, (novel, baseline) in zip(axes, valid_pairs):
        sn     = training_history[novel]
        sb     = training_history[baseline]
        steps  = sn.get("steps", [])
        n_ppls = sn.get("val_ppl", [])
        b_ppls = sb.get("val_ppl", [])
        if not steps or len(n_ppls) != len(b_ppls):
            continue

        gaps = [n - b for n, b in zip(n_ppls, b_ppls)]
        cn   = _style(novel)["color"]

        ax.plot(steps, gaps, color=cn, linewidth=2.5,
                label=f"{_style(novel)['label']} − {_style(baseline)['label']}")
        ax.axhline(0, color=PLOT_STYLE["white"], linewidth=0.8,
                   alpha=0.4, linestyle="--")
        ax.fill_between(steps, gaps, 0,
                        where=[g < 0 for g in gaps],
                        color=cn, alpha=0.15, label="Novel ahead")
        ax.set_xlabel("Training Step", fontsize=10)
        ax.set_ylabel("PPL Gap (positive = novel behind)", fontsize=9)
        ax.set_title(f"{_style(novel)['label']} vs {_style(baseline)['label']}",
                     fontsize=11, color=cn)
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)

    fig.suptitle("Advantage of Prime-Harmonic PE Over Geometric Baselines",
                 fontsize=12, color=PLOT_STYLE["gold"])
    plt.tight_layout()
    _save(fig, out_path)


def plot_degradation_bar(ppl_results: dict[str, dict], out_path: str) -> None:
    """Bar chart of final PPL at each context length."""
    ctx_vals = sorted({int(k) for d in ppl_results.values() for k in d})
    names    = list(ppl_results.keys())
    x        = np.arange(len(ctx_vals))
    width    = 0.8 / len(names)

    fig, ax  = plt.subplots(figsize=(12, 5.5))
    for i, name in enumerate(names):
        s    = _style(name)
        d    = ppl_results[name]
        vals = [d.get(k, d.get(str(k), float("nan"))) for k in ctx_vals]
        ax.bar(x + i * width, vals, width, label=s["label"],
               color=s["color"], alpha=0.85)

    ctx_labels = {512: "512", 1024: "1K", 2048: "2K", 4096: "4K",
                  8192: "8K", 16384: "16K"}
    ax.set_xticks(x + width * (len(names) - 1) / 2)
    ax.set_xticklabels([ctx_labels.get(v, str(v)) for v in ctx_vals])
    ax.set_xlabel("Context Length (tokens)", fontsize=11)
    ax.set_ylabel("Perplexity (lower = better)", fontsize=11)
    ax.set_title("Final PPL by Context Length", fontsize=13,
                 color=PLOT_STYLE["cyan"])
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3, axis="y")
    plt.tight_layout()
    _save(fig, out_path)
