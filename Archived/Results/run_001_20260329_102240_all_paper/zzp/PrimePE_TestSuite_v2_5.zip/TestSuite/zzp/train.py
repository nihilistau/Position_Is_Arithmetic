# TestSuite/zzp/train.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. ZZP training loop with per-epoch logging.
# ──────────────────────────────────────────────────────────────────────────────

from __future__ import annotations
import logging
import time

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

log = logging.getLogger("primePE")


def train_zzp(
    models: dict[str, nn.Module],
    train_loader: DataLoader,
    val_loader: DataLoader,
    epochs: int,
    lr: float,
    device: str,
    print_every: int = 25,
) -> dict[str, dict[str, list[float]]]:
    """
    Train all ZZP models in parallel on shared batches.

    Args:
        models:       {name: model} — all on the same device.
        train_loader: Training DataLoader.
        val_loader:   Validation DataLoader.
        epochs:       Number of epochs.
        lr:           Learning rate.
        device:       "cuda" or "cpu".
        print_every:  Log progress every N epochs.

    Returns:
        history: {name: {"train": [...], "val": [...]}} per-epoch MSE.
    """
    optimisers = {
        name: torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=0.01)
        for name, m in models.items()
    }
    criterion = nn.MSELoss()
    history   = {name: {"train": [], "val": []} for name in models}
    t_start   = time.time()

    for epoch in range(1, epochs + 1):

        # ── Train ──────────────────────────────────────────────────────────────
        for m in models.values():
            m.train()

        train_losses: dict[str, list[float]] = {n: [] for n in models}

        for x, y in train_loader:
            x, y = x.to(device), y.to(device)
            for name, model in models.items():
                optimisers[name].zero_grad()
                pred = model(x)
                loss = criterion(pred, y)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimisers[name].step()
                train_losses[name].append(loss.item())

        # ── Validate ───────────────────────────────────────────────────────────
        for m in models.values():
            m.eval()

        val_losses: dict[str, list[float]] = {n: [] for n in models}

        with torch.no_grad():
            for x, y in val_loader:
                x, y = x.to(device), y.to(device)
                for name, model in models.items():
                    pred = model(x)
                    val_losses[name].append(criterion(pred, y).item())

        # ── Record ─────────────────────────────────────────────────────────────
        for name in models:
            tl = sum(train_losses[name]) / max(len(train_losses[name]), 1)
            vl = sum(val_losses[name])   / max(len(val_losses[name]),   1)
            history[name]["train"].append(tl)
            history[name]["val"].append(vl)

        # ── Log ────────────────────────────────────────────────────────────────
        if epoch % print_every == 0:
            elapsed = time.time() - t_start
            log.info("Epoch %4d/%d | %.0fs", epoch, epochs, elapsed)
            for name in models:
                vl = history[name]["val"][-1]
                log.info("  %-22s val=%.5f", name, vl)

    return history
