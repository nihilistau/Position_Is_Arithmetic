# TestSuite/zzp/models.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. GeometricRoPE, SpectralALiBi, HarmonicString predictors.
#             All identical except PE/attention mechanism.
# ──────────────────────────────────────────────────────────────────────────────

from __future__ import annotations
import math
import sys
import os

import torch
import torch.nn as nn

# Allow imports from parent package
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from shared.primes import get_primes, harmonic_resonance_matrix, spectral_rope_freqs


# ── GeometricRoPEPredictor ────────────────────────────────────────────────────

class GeometricRoPEPredictor(nn.Module):
    """
    Baseline: standard sinusoidal PE + TransformerEncoder.
    Geometric frequency progressions (base 10000).
    """

    def __init__(self, d_model: int = 64, n_heads: int = 4,
                 n_layers: int = 3, seq_len: int = 50) -> None:
        super().__init__()
        self.proj = nn.Linear(1, d_model)
        self.enc  = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(
                d_model, n_heads, dim_feedforward=d_model * 4,
                batch_first=True, dropout=0.1,
            ),
            num_layers=n_layers,
        )
        self.head = nn.Linear(d_model, 1)

        # Sinusoidal PE buffer
        pos = torch.arange(seq_len).unsqueeze(1).float()
        dim = torch.arange(0, d_model, 2).float()
        pe  = torch.zeros(1, seq_len, d_model)
        pe[0, :, 0::2] = torch.sin(pos / (10000 ** (dim / d_model)))
        pe[0, :, 1::2] = torch.cos(pos / (10000 ** (dim / d_model)))
        self.register_buffer("pe", pe)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x    = self.proj(x.unsqueeze(-1)) + self.pe[:, :x.size(1)]
        mask = nn.Transformer.generate_square_subsequent_mask(
            x.size(1), device=x.device)
        x    = self.enc(x, mask=mask, is_causal=True)
        return self.head(x[:, -1, :]).squeeze(-1)


# ── SpectralALiBiPredictor ────────────────────────────────────────────────────

class SpectralALiBiPredictor(nn.Module):
    """
    SpectralRoPE + learned ALiBi distance bias.
    Tiered per-head prime frequencies + convergence prior.
    """

    def __init__(self, d_model: int = 64, n_heads: int = 4,
                 n_layers: int = 3, seq_len: int = 50) -> None:
        super().__init__()
        self.d_model  = d_model
        self.n_heads  = n_heads
        self.head_dim = d_model // n_heads

        self.proj = nn.Linear(1, d_model)

        # Spectral frequencies
        hf = spectral_rope_freqs(d_model, n_heads)
        self.register_buffer("head_freqs", hf)

        # Learnable ALiBi slopes and freq scale
        alibi_init = torch.tensor(
            [2 ** (-8 * (h + 1) / n_heads) for h in range(n_heads)],
            dtype=torch.float32)
        self.slopes     = nn.Parameter(alibi_init)
        self.freq_scale = nn.Parameter(torch.ones(n_heads))

        self.layers = nn.ModuleList(
            [self._make_layer(d_model) for _ in range(n_layers)])
        self.norm = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, 1)

    def _apply_rope(self, x: torch.Tensor) -> torch.Tensor:
        B, H, T, D = x.shape
        t  = torch.arange(T, device=x.device, dtype=x.dtype)
        sf = (self.head_freqs[:, :D // 2]
              * self.freq_scale.abs().unsqueeze(1)).to(x.dtype)
        ph = torch.einsum("t,hd->htd", t, sf)
        c, s  = ph.cos().unsqueeze(0), ph.sin().unsqueeze(0)
        x1, x2 = x[..., 0::2], x[..., 1::2]
        return torch.stack([x1 * c - x2 * s, x1 * s + x2 * c], -1).flatten(-2)

    def _make_layer(self, d: int) -> nn.Module:
        parent = self

        class _Layer(nn.Module):
            def __init__(lyr) -> None:
                super().__init__()
                lyr.qkv  = nn.Linear(d, 3 * d, bias=False)
                lyr.out  = nn.Linear(d, d, bias=False)
                lyr.n1   = nn.LayerNorm(d)
                lyr.n2   = nn.LayerNorm(d)
                lyr.ff   = nn.Sequential(
                    nn.Linear(d, d * 4), nn.GELU(), nn.Linear(d * 4, d))
                lyr.sc   = parent.head_dim ** -0.5

            def forward(lyr, x: torch.Tensor) -> torch.Tensor:
                B, T, C = x.shape
                q, k, v = (lyr.qkv(lyr.n1(x))
                           .reshape(B, T, 3, parent.n_heads, parent.head_dim)
                           .permute(2, 0, 3, 1, 4).unbind(0))
                q, k    = parent._apply_rope(q), parent._apply_rope(k)
                sc      = (q @ k.transpose(-2, -1)) * lyr.sc
                pos     = torch.arange(T, device=x.device, dtype=x.dtype)
                dist    = (pos.unsqueeze(0) - pos.unsqueeze(1)).abs()
                alibi   = (-parent.slopes.abs().view(1, parent.n_heads, 1, 1)
                           * dist.unsqueeze(0).unsqueeze(0))
                cm      = torch.triu(
                    torch.full((T, T), float("-inf"), device=x.device), 1)
                w       = (sc + alibi + cm).softmax(-1)
                x       = x + lyr.out(
                    (w @ v).transpose(1, 2).reshape(B, T, C))
                x       = x + lyr.ff(lyr.n2(x))
                return x

        return _Layer()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.proj(x.unsqueeze(-1))
        for layer in self.layers:
            x = layer(x)
        return self.head(self.norm(x[:, -1, :])).squeeze(-1)


# ── HarmonicStringPredictor ───────────────────────────────────────────────────

class HarmonicStringPredictor(nn.Module):
    """
    Harmonic resonance score function + learned ALiBi bias.
    score(i,j) = alpha*R(i-j) + alibi_bias + beta*QK(i,j)
    """

    def __init__(self, d_model: int = 64, n_heads: int = 4,
                 n_layers: int = 3, seq_len: int = 50,
                 n_primes: int = 32) -> None:
        super().__init__()
        self.d_model  = d_model
        self.n_heads  = n_heads
        self.head_dim = d_model // n_heads
        self.n_primes = n_primes

        self.proj = nn.Linear(1, d_model)

        alibi_init = torch.tensor(
            [2 ** (-8 * (h + 1) / n_heads) for h in range(n_heads)],
            dtype=torch.float32)
        self.slopes = nn.Parameter(alibi_init)
        self.head_alpha = nn.Parameter(torch.ones(n_heads))
        self.head_beta  = nn.Parameter(torch.ones(n_heads))

        self.layers = nn.ModuleList(
            [self._make_layer(d_model) for _ in range(n_layers)])
        self.norm = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, 1)

    def _make_layer(self, d: int) -> nn.Module:
        parent = self

        class _Layer(nn.Module):
            def __init__(lyr) -> None:
                super().__init__()
                lyr.qkv  = nn.Linear(d, 3 * d, bias=False)
                lyr.out  = nn.Linear(d, d, bias=False)
                lyr.n1   = nn.LayerNorm(d)
                lyr.n2   = nn.LayerNorm(d)
                lyr.ff   = nn.Sequential(
                    nn.Linear(d, d * 4), nn.GELU(), nn.Linear(d * 4, d))
                lyr.sc   = parent.head_dim ** -0.5

            def forward(lyr, x: torch.Tensor) -> torch.Tensor:
                B, T, C = x.shape
                q, k, v = (lyr.qkv(lyr.n1(x))
                           .reshape(B, T, 3, parent.n_heads, parent.head_dim)
                           .permute(2, 0, 3, 1, 4).unbind(0))
                qk   = (q @ k.transpose(-2, -1)) * lyr.sc

                R    = harmonic_resonance_matrix(T, parent.n_primes)
                R    = R.to(x.device, x.dtype).unsqueeze(0).unsqueeze(0)

                pos  = torch.arange(T, device=x.device, dtype=x.dtype)
                dist = (pos.unsqueeze(0) - pos.unsqueeze(1)).abs()
                al   = (-parent.slopes.abs().view(1, parent.n_heads, 1, 1)
                        * dist.unsqueeze(0).unsqueeze(0))

                ha   = parent.head_alpha.abs().view(1, parent.n_heads, 1, 1)
                hb   = parent.head_beta.abs().view(1, parent.n_heads, 1, 1)
                cm   = torch.triu(
                    torch.full((T, T), float("-inf"), device=x.device), 1)
                w    = (ha * R + al + hb * qk + cm).softmax(-1)
                x    = x + lyr.out(
                    (w @ v).transpose(1, 2).reshape(B, T, C))
                x    = x + lyr.ff(lyr.n2(x))
                return x

        return _Layer()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.proj(x.unsqueeze(-1))
        for layer in self.layers:
            x = layer(x)
        return self.head(self.norm(x[:, -1, :])).squeeze(-1)


# ── Factory ───────────────────────────────────────────────────────────────────

def make_model(variant: str, cfg: dict) -> nn.Module:
    """
    Instantiate a ZZP model by variant name.

    Args:
        variant: "geometric_rope" | "spectral_alibi" | "harmonic_string"
        cfg: ZZP_CONFIG dict.
    """
    kwargs = dict(
        d_model  = cfg["d_model"],
        n_heads  = cfg["n_heads"],
        n_layers = cfg["n_layers"],
        seq_len  = cfg["seq_len"],
    )
    if variant == "geometric_rope":
        return GeometricRoPEPredictor(**kwargs)
    elif variant == "spectral_alibi":
        return SpectralALiBiPredictor(**kwargs)
    elif variant == "harmonic_string":
        return HarmonicStringPredictor(**kwargs, n_primes=cfg.get("n_primes", 32))
    else:
        raise ValueError(f"Unknown ZZP variant: {variant}")


def param_count(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())
