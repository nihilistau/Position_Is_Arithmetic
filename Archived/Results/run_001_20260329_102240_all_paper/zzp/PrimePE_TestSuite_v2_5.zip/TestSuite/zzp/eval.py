# TestSuite/zzp/eval.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. ZZP evaluation, results compilation, console report.
# ──────────────────────────────────────────────────────────────────────────────

from __future__ import annotations
import logging
import os

import torch
import torch.nn as nn
import numpy as np
from torch.utils.data import DataLoader

log = logging.getLogger("primePE")


def evaluate_all(
    models: dict[str, nn.Module],
    val_loader: DataLoader,
    device: str,
) -> dict[str, float]:
    """
    Final MSE evaluation for all models on the validation set.

    Returns:
        {name: final_val_mse}
    """
    criterion = nn.MSELoss()
    results: dict[str, float] = {}

    for name, model in models.items():
        model.eval()
        losses = []
        with torch.no_grad():
            for x, y in val_loader:
                x, y = x.to(device), y.to(device)
                pred = model(x)
                losses.append(criterion(pred, y).item())
        results[name] = sum(losses) / max(len(losses), 1)

    return results


def get_predictions(
    models: dict[str, nn.Module],
    val_loader: DataLoader,
    device: str,
    max_samples: int = 200,
) -> dict[str, tuple[list[float], list[float]]]:
    """
    Collect predictions and actuals for each model.

    Returns:
        {name: (preds, actuals)}
    """
    out: dict[str, tuple[list[float], list[float]]] = {n: ([], []) for n in models}

    for name, model in models.items():
        model.eval()
        preds, actuals = [], []
        with torch.no_grad():
            for x, y in val_loader:
                if len(preds) >= max_samples:
                    break
                x, y = x.to(device), y.to(device)
                pred = model(x)
                preds.extend(pred.cpu().tolist())
                actuals.extend(y.cpu().tolist())
        out[name] = (preds[:max_samples], actuals[:max_samples])

    return out


def compile_results(
    history: dict[str, dict],
    final_mse: dict[str, float],
    gap_mean: float,
    gap_std: float,
    epochs: int,
    cfg: dict,
) -> dict:
    """Build the results dict saved to results.json."""
    baseline = final_mse.get("geometric_rope", 1.0)
    summary  = {}

    for name, mse in final_mse.items():
        val_hist = history[name]["val"]
        best_mse = min(val_hist) if val_hist else mse
        best_ep  = int(np.argmin(val_hist) + 1) if val_hist else 0
        rel      = (mse - baseline) / max(baseline, 1e-8) * 100

        summary[name] = {
            "final_val_mse": round(mse, 6),
            "best_val_mse":  round(best_mse, 6),
            "best_epoch":    best_ep,
            "vs_geometric":  round(rel, 2),
        }

    return {
        "config": {
            "n_zeros":    cfg["n_zeros"],
            "seq_len":    cfg["seq_len"],
            "epochs_run": epochs,
            "lr":         cfg["lr"],
            "batch_size": cfg["batch_size"],
            "d_model":    cfg["d_model"],
            "n_heads":    cfg["n_heads"],
            "n_layers":   cfg["n_layers"],
            "n_primes":   cfg.get("n_primes", 32),
        },
        "gap_mean":    gap_mean,
        "gap_std":     gap_std,
        "summary":     summary,
        "history_len": {n: len(h["val"]) for n, h in history.items()},
    }


def print_report(results: dict) -> None:
    """Print a concise results table to console."""
    print()
    print("=" * 65)
    print("ZETA-ZERO PREDICTOR — RESULTS")
    print("=" * 65)
    print(f"{'Model':<24} {'Final MSE':>10} {'Best MSE':>10} {'Best Ep':>8} {'vs Geom':>9}")
    print("-" * 65)
    for name, d in results["summary"].items():
        print(
            f"{name:<24} {d['final_val_mse']:>10.5f} "
            f"{d['best_val_mse']:>10.5f} {d['best_epoch']:>8} "
            f"{d['vs_geometric']:>+8.1f}%"
        )
    print()
    print("vs Geom = (final_mse - geometric_rope) / geometric_rope * 100")
    print("Negative = model is BETTER than geometric RoPE")
    print("=" * 65)
