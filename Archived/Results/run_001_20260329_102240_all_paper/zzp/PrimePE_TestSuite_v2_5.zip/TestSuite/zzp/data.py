# TestSuite/zzp/data.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. Zeta zero loading, gap dataset, Windows-safe DataLoader.
# ──────────────────────────────────────────────────────────────────────────────

from __future__ import annotations
import json
import logging
import os

import torch
from torch.utils.data import Dataset, DataLoader

log = logging.getLogger("primePE")


def load_zeros(cache_path: str, n: int = 1000) -> list[float]:
    """
    Load first n certified Riemann zeta zeros.
    Uses cached JSON if available; otherwise generates with mpmath.

    Args:
        cache_path: Path to cache JSON file.
        n: Number of zeros to return.

    Returns:
        List of imaginary parts t_1, t_2, ..., t_n.
    """
    if os.path.exists(cache_path):
        with open(cache_path, encoding="utf-8") as f:
            zeros = json.load(f)
        log.info("Loaded %d zeta zeros from cache: %s", len(zeros), cache_path)
        return zeros[:n]

    log.info("Generating %d zeta zeros with mpmath (this takes ~2 min)...", n)
    try:
        from mpmath import mp, zetazero
        mp.dps = 20
        zeros = [float(zetazero(i).imag) for i in range(1, n + 1)]
        os.makedirs(os.path.dirname(os.path.abspath(cache_path)), exist_ok=True)
        with open(cache_path, "w", encoding="utf-8") as f:
            json.dump(zeros, f, indent=2)
        log.info("Generated and cached %d zeros -> %s", n, cache_path)
        return zeros
    except ImportError:
        raise RuntimeError(
            "mpmath not installed. Run: pip install mpmath\n"
            "Or place a zeta_zeros_1000.json file at: " + cache_path
        )


def compute_gaps(zeros: list[float]) -> list[float]:
    """Return list of consecutive differences between zeros."""
    return [zeros[i + 1] - zeros[i] for i in range(len(zeros) - 1)]


# ── Dataset ───────────────────────────────────────────────────────────────────
# Module-level class required for Windows pickle (num_workers compatibility)

class ZetaGapDataset(Dataset):
    """
    Sliding window dataset over normalised zeta zero gaps.
    Input: previous seq_len gaps. Target: next gap.
    """

    def __init__(self, gaps: torch.Tensor, seq_len: int = 50) -> None:
        self.gaps    = gaps
        self.seq_len = seq_len

    def __len__(self) -> int:
        return len(self.gaps) - self.seq_len

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, torch.Tensor]:
        return (
            self.gaps[idx:idx + self.seq_len],
            self.gaps[idx + self.seq_len],
        )


def make_loaders(
    zeros: list[float],
    seq_len: int = 50,
    batch_size: int = 32,
    train_split: float = 0.8,
) -> tuple[DataLoader, DataLoader, float, float]:
    """
    Build train and val DataLoaders from zeta zeros.

    Returns:
        (train_loader, val_loader, gap_mean, gap_std)
    """
    gaps_t    = torch.tensor(compute_gaps(zeros), dtype=torch.float32)
    gap_mean  = gaps_t.mean().item()
    gap_std   = gaps_t.std().item()
    gaps_norm = (gaps_t - gap_mean) / gap_std

    n_train   = int(len(gaps_norm) * train_split)
    train_ds  = ZetaGapDataset(gaps_norm[:n_train], seq_len)
    val_ds    = ZetaGapDataset(gaps_norm[n_train:], seq_len)

    # num_workers=0 required on Windows
    train_loader = DataLoader(train_ds, batch_size=batch_size,
                              shuffle=True, num_workers=0)
    val_loader   = DataLoader(val_ds, batch_size=batch_size,
                              shuffle=False, num_workers=0)

    log.info(
        "ZZP dataset: %d zeros | %d gaps | train=%d val=%d | "
        "mean=%.4f std=%.4f",
        len(zeros), len(gaps_t), len(train_ds), len(val_ds),
        gap_mean, gap_std,
    )
    return train_loader, val_loader, gap_mean, gap_std
