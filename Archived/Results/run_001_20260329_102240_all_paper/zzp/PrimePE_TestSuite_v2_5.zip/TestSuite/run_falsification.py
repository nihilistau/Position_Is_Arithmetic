#!/usr/bin/env python3
# TestSuite/run_falsification.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. Falsification suite: tests whether prime arithmetic
#             structure specifically matters, vs having diverse frequencies.
#
# THE QUESTION:
#   We claim prime-harmonic PE works because of prime arithmetic structure.
#   But maybe it just works because we have diverse non-geometric frequencies.
#   These tests isolate that: scrambled primes, random freqs, composites.
#
# INTERPRETATION:
#   If prime_tiered >> scrambled_prime:
#     → The ORDERING of primes across tiers matters, not just having primes.
#   If prime_tiered >> random_freq:
#     → Prime numbers specifically (not just diverse non-geometric freqs) matter.
#   If prime_tiered >> composite_only:
#     → The multiplicative structure of primes (not just any integers) matters.
#   If prime_tiered >> prime_noscale:
#     → The learned freq_scale (self-discovered basis) matters.
#   If prime_tiered ~ scrambled_prime ~ random_freq:
#     → Frequency diversity is the active ingredient, not prime structure.
#     → We should revise our theoretical claims.
#
# Usage:
#   python run_falsification.py                      # full suite, 3000 steps
#   python run_falsification.py --steps 1000         # quick sanity check
#   python run_falsification.py --quick              # 5 core variants only
#   python run_falsification.py --steps 5000 --ctx 512 1024 2048  # full eval
# ──────────────────────────────────────────────────────────────────────────────

import argparse
import os
import sys
import time

import torch

SUITE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SUITE_DIR)

from config import DEVICE, DTYPE, RESULTS_DIR, TOKEN_CACHE_DIR
from shared.utils import setup_run_dir, setup_logger, save_json, print_banner, gpu_info
from shared.plots import plot_ppl_vs_context, plot_convergence
from falsification.models import VARIANTS, VARIANTS_QUICK, make_model
from falsification.train_eval import train_parallel, eval_ppl_at_contexts
from freq_analysis.plots import plot_falsification_convergence


# ── RTX 2060 optimised mini config ────────────────────────────────────────────
FALSIFICATION_CFG = {
    "d_model":    256,
    "n_heads":    8,
    "n_layers":   6,
    "ffn_dim":    1024,
    "dropout":    0.1,
    "vocab_size": 50257,
    "train_seq_len": 1024,
    "max_steps":  3000,
    "batch_size": 1,
    "grad_accum": 16,
    "lr":         3e-4,
    "warmup_steps": 300,
    "eval_every": 250,
    "eval_batches": 40,
    "eval_ctx_lens": [512, 1024, 2048],
}


def parse_args():
    p = argparse.ArgumentParser(
        description="PrimePE Falsification Suite",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("--steps",  type=int, default=FALSIFICATION_CFG["max_steps"],
                   help="Training steps (default: 3000)")
    p.add_argument("--quick",  action="store_true",
                   help="Run quick 5-variant subset only")
    p.add_argument("--variants", nargs="+", default=None,
                   choices=list(VARIANTS.keys()),
                   help="Specific variants to run")
    p.add_argument("--ctx", nargs="+", type=int,
                   default=FALSIFICATION_CFG["eval_ctx_lens"],
                   help="Context lengths for final eval")
    p.add_argument("--no-eval", action="store_true",
                   help="Skip multi-context eval after training")
    return p.parse_args()


def interpret_results(history: dict) -> list[str]:
    """Generate interpretation statements from results."""
    finals = {v: h["val_ppl"][-1] if h["val_ppl"] else float("inf")
              for v, h in history.items()}

    prime = finals.get("prime_tiered", float("inf"))
    msgs  = []

    def diff(v: str) -> str:
        f = finals.get(v, float("inf"))
        if f == float("inf"):
            return "NOT RUN"
        d = f - prime
        return f"{d:+.1f} PPL ({'+' if d > 0 else ''}{d / prime * 100:.1f}%)"

    msgs.append(f"prime_tiered final PPL: {prime:.1f}")
    msgs.append("")
    msgs.append("FALSIFICATION RESULTS:")

    checks = [
        ("scrambled_prime", "Tier ordering matters (not just prime set)"),
        ("random_freq",     "Prime numbers specifically matter"),
        ("composite_only",  "Multiplicative structure matters"),
        ("prime_noscale",   "Learned freq_scale matters"),
        ("antiresonance",   "Primorial resonance structure matters"),
        ("alibi",           "vs ALiBi baseline"),
        ("geometric_rope",  "vs geometric RoPE+ALiBi baseline"),
    ]

    for variant, description in checks:
        if variant in finals:
            d = finals[variant] - prime
            verdict = "SUPPORTS" if d > 2 else ("NEUTRAL" if d > -2 else "AGAINST")
            msgs.append(f"  {verdict:8s}  {description}")
            msgs.append(f"           {variant}: {diff(variant)}")

    return msgs


def main():
    args = parse_args()

    run_dir  = setup_run_dir(RESULTS_DIR, prefix="falsification")
    false_dir = os.path.join(run_dir, "falsification")
    os.makedirs(false_dir, exist_ok=True)

    log = setup_logger(run_dir, "primePE.falsification")

    print_banner("FALSIFICATION SUITE — PrimePE TestSuite")
    log.info("Run dir: %s", run_dir)
    log.info("Device: %s | %s", DEVICE, gpu_info())
    log.info("")
    log.info("THE QUESTION: Is it prime arithmetic structure specifically,")
    log.info("or just having diverse non-geometric frequencies?")

    # Select variants
    if args.variants:
        variants = args.variants
    elif args.quick:
        variants = VARIANTS_QUICK
    else:
        variants = list(VARIANTS.keys())

    log.info("Variants: %s", variants)

    cfg = dict(FALSIFICATION_CFG)
    cfg["max_steps"] = args.steps

    # Build models
    print_banner("Building Models")
    models = {}
    for v in variants:
        m = make_model(v, cfg).to(DEVICE)
        n = sum(p.numel() for p in m.parameters())
        log.info("  %-38s %8d params", VARIANTS.get(v, v)[:38], n)
        models[v] = m

    # Data
    print_banner("Loading Data")
    from pe_eval.data import tokenise_wikitext, ChunkDataset
    from torch.utils.data import DataLoader

    chunks_tr = tokenise_wikitext("train",      cfg["train_seq_len"], TOKEN_CACHE_DIR)
    chunks_v  = tokenise_wikitext("validation", cfg["train_seq_len"], TOKEN_CACHE_DIR)
    tr_ds = ChunkDataset(chunks_tr)
    v_ds  = ChunkDataset(chunks_v)
    tr_loader = DataLoader(tr_ds, batch_size=cfg["batch_size"],
                           shuffle=True, num_workers=0, drop_last=True)
    v_loader  = DataLoader(v_ds, batch_size=1,
                           shuffle=False, num_workers=0, drop_last=True)
    log.info("Train: %d chunks | Val: %d chunks", len(tr_ds), len(v_ds))

    # Train
    print_banner(f"Training — {cfg['max_steps']} steps")
    t0 = time.time()
    history = train_parallel(models, tr_loader, v_loader, cfg, DEVICE, DTYPE)
    elapsed = time.time() - t0
    log.info("Training complete: %.0fs", elapsed)

    # Save history
    save_json(history, os.path.join(false_dir, "training_history.json"))

    # Plots
    print_banner("Generating Plots")
    plot_falsification_convergence(
        history, os.path.join(false_dir, "falsification_convergence.png"))
    log.info("falsification_convergence.png saved.")

    # Multi-context eval
    if not args.no_eval:
        print_banner("Multi-Context Evaluation")
        ppl_results = eval_ppl_at_contexts(
            models, sorted(args.ctx), TOKEN_CACHE_DIR, DEVICE, DTYPE,
            n_batches=cfg["eval_batches"])
        save_json(ppl_results, os.path.join(false_dir, "ppl_results.json"))
        plot_ppl_vs_context(
            ppl_results, os.path.join(false_dir, "ppl_vs_context.png"),
            train_ctx=cfg["train_seq_len"])
        log.info("ppl_vs_context.png saved.")
    else:
        ppl_results = {}

    # Interpretation
    print_banner("INTERPRETATION")
    msgs = interpret_results(history)
    for msg in msgs:
        log.info(msg)

    # Save full results
    results = {
        "config":      cfg,
        "variants":    {v: VARIANTS[v] for v in variants if v in VARIANTS},
        "history":     {v: {"final_ppl": h["val_ppl"][-1] if h["val_ppl"] else None,
                             "n_steps":   len(h["steps"])}
                        for v, h in history.items()},
        "ppl_results": ppl_results,
        "interpretation": msgs,
        "elapsed_seconds": round(elapsed, 1),
    }
    save_json(results, os.path.join(false_dir, "results.json"))

    print()
    log.info("Results saved to: %s", false_dir)


if __name__ == "__main__":
    main()
