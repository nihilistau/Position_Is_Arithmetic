#!/usr/bin/env python3
# TestSuite/runpod/launch_g4.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. Full G4-equivalent training run for RunPod A100/H100.
#             Trains all variants in parallel, saves checkpoints to /workspace.
#
# This reproduces the G4 20K step run at full scale.
# Designed for A100 80GB or H100 80GB (RunPod $2-4/hr).
#
# Usage:
#   python runpod/launch_g4.py                    # standard 20K steps
#   python runpod/launch_g4.py --steps 10000      # half run (cheaper)
#   python runpod/launch_g4.py --harmonic         # include harmonic variants
#   python runpod/launch_g4.py --ctx 8192         # 8K training context (needs TurboQuant)
# ──────────────────────────────────────────────────────────────────────────────

import argparse
import gc
import math
import os
import sys
import time

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

SUITE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, SUITE_DIR)

from config import DEVICE, DTYPE, TOKEN_CACHE_DIR
from shared.utils import setup_run_dir, setup_logger, save_json, print_banner, gpu_info
from shared.plots import plot_convergence, plot_ppl_vs_context
from pe_eval.models import PrimePEModel
from pe_eval.data import tokenise_wikitext, ChunkDataset, make_eval_loader

RESULTS_DIR = "/workspace/TestSuite/results"

# ── Full G4 config ─────────────────────────────────────────────────────────────
G4_CONFIG = {
    "d_model":       768,
    "n_heads":       12,
    "n_layers":      24,
    "ffn_dim":       3072,
    "dropout":       0.1,
    "vocab_size":    50257,
    "train_seq_len": 4096,
    "max_steps":     20000,
    "batch_size":    1,
    "grad_accum":    32,
    "lr":            3e-4,
    "warmup_steps":  1000,
    "eval_every":    500,
    "eval_ctx_lens": [512, 1024, 2048, 4096, 8192, 16384],
    "eval_batches":  80,
}

VARIANTS_STANDARD = ["rope", "alibi", "spectral_rope", "spectral_rope_alibi"]
VARIANTS_HARMONIC  = ["harmonic_string", "harmonic_string_alibi"]


def parse_args():
    p = argparse.ArgumentParser(description="PrimePE G4-equivalent RunPod run")
    p.add_argument("--steps",    type=int, default=G4_CONFIG["max_steps"])
    p.add_argument("--ctx",      type=int, default=G4_CONFIG["train_seq_len"])
    p.add_argument("--harmonic", action="store_true",
                   help="Include HarmonicString variants (slower)")
    p.add_argument("--save-every", type=int, default=2000,
                   help="Save checkpoints every N steps")
    return p.parse_args()


def main():
    args = parse_args()

    run_dir   = setup_run_dir(RESULTS_DIR, prefix="g4")
    log       = setup_logger(run_dir, "primePE.g4")

    print_banner("G4 FULL RUN — PrimePE TestSuite (RunPod)")
    log.info("Run dir: %s", run_dir)
    log.info("Device: %s | %s", DEVICE, gpu_info())

    cfg            = dict(G4_CONFIG)
    cfg["max_steps"]     = args.steps
    cfg["train_seq_len"] = args.ctx
    save_json(cfg, os.path.join(run_dir, "config.json"))

    variants = VARIANTS_STANDARD + (VARIANTS_HARMONIC if args.harmonic else [])
    log.info("Variants: %s", variants)

    # ── Build models ──────────────────────────────────────────────────────────
    print_banner("Building Models")
    models = {}
    for pe in variants:
        m = PrimePEModel(cfg, pe).to(DEVICE)
        if torch.cuda.is_available():
            m = torch.compile(m)
        n = sum(p.numel() for p in m.parameters())
        log.info("  %-30s %10d params", pe, n)
        models[pe] = m

    # ── Data ──────────────────────────────────────────────────────────────────
    print_banner("Data")
    cache_dir = os.path.join(SUITE_DIR, "token_cache")
    chunks_tr = tokenise_wikitext("train",      cfg["train_seq_len"], cache_dir)
    chunks_v  = tokenise_wikitext("validation", cfg["train_seq_len"], cache_dir)
    tr_ds = ChunkDataset(chunks_tr)
    v_ds  = ChunkDataset(chunks_v)
    tr_loader = DataLoader(tr_ds, batch_size=1, shuffle=True,
                           num_workers=4, drop_last=True, pin_memory=True)
    v_loader  = DataLoader(v_ds, batch_size=1, shuffle=False,
                           num_workers=2, drop_last=True)
    log.info("Train: %d  Val: %d", len(tr_ds), len(v_ds))

    # ── Optimisers ────────────────────────────────────────────────────────────
    opts = {pe: torch.optim.AdamW(m.parameters(), lr=cfg["lr"],
                                   weight_decay=0.01)
            for pe, m in models.items()}

    def lr_fn(step):
        w = cfg["warmup_steps"]
        s = cfg["max_steps"]
        if step < w:
            return step / max(w, 1)
        t = (step - w) / max(s - w, 1)
        return 0.5 * (1 + math.cos(math.pi * t))

    scheds = {pe: torch.optim.lr_scheduler.LambdaLR(opts[pe], lr_fn)
              for pe in models}
    scaler = torch.cuda.amp.GradScaler()
    history = {pe: {"steps": [], "val_ppl": []} for pe in models}
    accum   = cfg["grad_accum"]
    step    = 0
    t_start = time.time()

    for m in models.values():
        m.train()

    data_iter = iter(tr_loader)
    dev_type  = "cuda"

    # ── Training loop ─────────────────────────────────────────────────────────
    print_banner("Training")
    while step < cfg["max_steps"]:

        for _ in range(accum):
            try:
                x, y = next(data_iter)
            except StopIteration:
                data_iter = iter(tr_loader)
                x, y = next(data_iter)
            x, y = x.to(DEVICE), y.to(DEVICE)

            for pe, model in models.items():
                with torch.autocast(device_type=dev_type, dtype=DTYPE):
                    logits = model(x)
                    loss   = F.cross_entropy(
                        logits.reshape(-1, cfg["vocab_size"]),
                        y.reshape(-1)) / accum
                scaler.scale(loss).backward()

        for pe, model in models.items():
            scaler.unscale_(opts[pe])
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler.step(opts[pe])
            opts[pe].zero_grad()
            scheds[pe].step()
        scaler.update()
        step += 1

        # Eval
        if step % cfg["eval_every"] == 0 or step == cfg["max_steps"]:
            elapsed = time.time() - t_start
            log.info("Step %5d/%d | %.0fs | lr=%.2e",
                     step, cfg["max_steps"], elapsed,
                     opts[variants[0]].param_groups[0]["lr"])

            for pe, model in models.items():
                model.eval()
                losses = []
                with torch.no_grad():
                    for i, (x, y) in enumerate(v_loader):
                        if i >= cfg["eval_batches"]:
                            break
                        x, y = x.to(DEVICE), y.to(DEVICE)
                        with torch.autocast(device_type=dev_type, dtype=DTYPE):
                            logits = model(x)
                        losses.append(F.cross_entropy(
                            logits.reshape(-1, cfg["vocab_size"]),
                            y.reshape(-1)).item())
                ppl = math.exp(sum(losses) / max(len(losses), 1))
                history[pe]["steps"].append(step)
                history[pe]["val_ppl"].append(ppl)
                log.info("  %-30s ppl=%7.1f", pe, ppl)
                model.train()

            # Save history every eval
            save_json(history, os.path.join(run_dir, "training_history.json"))

        # Checkpoint save
        if step % args.save_every == 0 or step == cfg["max_steps"]:
            ckpt_dir = os.path.join(run_dir, f"ckpts_step{step:05d}")
            os.makedirs(ckpt_dir, exist_ok=True)
            for pe, model in models.items():
                raw = model._orig_mod if hasattr(model, "_orig_mod") else model
                path = os.path.join(ckpt_dir, f"ckpt_{pe}.pt")
                torch.save(raw.state_dict(), path)
            log.info("Checkpoints saved @ step %d -> %s", step, ckpt_dir)

    # ── Final degradation eval ────────────────────────────────────────────────
    print_banner("Final Evaluation")
    ppl_results = {}
    for pe, model in models.items():
        log.info("Final eval: %s", pe)
        model.eval()
        ppls = {}
        for ctx in cfg["eval_ctx_lens"]:
            loader = make_eval_loader("test", ctx, cache_dir)
            losses = []
            with torch.no_grad():
                for i, (x, y) in enumerate(loader):
                    if i >= cfg["eval_batches"]:
                        break
                    x, y = x.to(DEVICE), y.to(DEVICE)
                    with torch.autocast(device_type=dev_type, dtype=DTYPE):
                        logits = model(x)
                    losses.append(F.cross_entropy(
                        logits.reshape(-1, cfg["vocab_size"]),
                        y.reshape(-1)).item())
            ppls[ctx] = round(math.exp(sum(losses) / max(len(losses), 1)), 2)
            log.info("  ctx=%d  ppl=%.1f", ctx, ppls[ctx])
        ppl_results[pe] = ppls
        del model
        gc.collect()
        torch.cuda.empty_cache()

    # Save and plot
    save_json(ppl_results, os.path.join(run_dir, "ppl_results.json"))
    save_json(history,     os.path.join(run_dir, "training_history.json"))

    plot_convergence(history, os.path.join(run_dir, "convergence.png"))
    plot_ppl_vs_context(ppl_results, os.path.join(run_dir, "ppl_vs_context.png"),
                        train_ctx=cfg["train_seq_len"])
    log.info("Plots saved.")

    elapsed_total = time.time() - t_start
    log.info("Total runtime: %.0f seconds (%.1f hours)",
             elapsed_total, elapsed_total / 3600)
    log.info("All results in: %s", run_dir)


if __name__ == "__main__":
    main()
