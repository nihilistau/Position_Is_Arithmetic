#!/bin/bash
# TestSuite/runpod/setup.sh
# Version: v2.0.0 | Author: Knack | 2026-03-29
set -e
WORKSPACE="/workspace"
SUITE="$WORKSPACE/TestSuite"

echo "============================================================"
echo "  PrimePE RunPod Setup v2.0"
echo "============================================================"

# GPU detection
echo ""
echo "[GPU]"
python3 -c "
import subprocess
r = subprocess.run(['nvidia-smi','--query-gpu=name,memory.total','--format=csv,noheader'],
    capture_output=True, text=True)
if r.returncode == 0:
    for line in r.stdout.strip().split('\n'):
        print(f'  {line}')
else:
    print('  nvidia-smi not found')
" 2>/dev/null || echo "  GPU check failed"

# Persistent workspace
echo ""
echo "[Workspace]"
mkdir -p $WORKSPACE/results $WORKSPACE/token_cache $WORKSPACE/checkpoints
echo "  /workspace/results/     <- run outputs (persisted)"
echo "  /workspace/checkpoints/ <- final checkpoints (persisted)"
echo "  /workspace/token_cache/ <- WikiText-103 tokens (cached once)"

# Unzip TestSuite
echo ""
echo "[TestSuite]"
if [ -f "$WORKSPACE/PrimePE_TestSuite_v2.zip" ]; then
    cd $WORKSPACE && unzip -q -o PrimePE_TestSuite_v2.zip
    echo "  Unzipped ✓"
else
    echo "  ERROR: PrimePE_TestSuite_v2.zip not found in /workspace"
    echo "  Upload it via RunPod file browser then re-run"
    exit 1
fi

# Dependencies
echo ""
echo "[Dependencies]"
pip install -q --upgrade pip
pip install -q transformers datasets mpmath matplotlib numpy scipy tqdm
echo "  Installed ✓"

# Verify
echo ""
echo "[Verification]"
python3 -c "
import torch
print(f'  PyTorch: {torch.__version__}')
print(f'  CUDA: {torch.cuda.is_available()}')
if torch.cuda.is_available():
    p = torch.cuda.get_device_properties(0)
    gb = p.total_memory/1e9
    print(f'  GPU: {p.name}  VRAM: {gb:.0f}GB')
    if gb >= 70:   print('  -> A100/H100: full parallel run capable')
    elif gb >= 40: print('  -> A6000: parallel run capable')
    else:          print('  -> Smaller GPU: use sequential mode')
"

# Config
cat > $SUITE/runpod_config.py << 'PYEOF'
WORKSPACE   = "/workspace"
RESULTS_DIR = "/workspace/results"
TOKEN_CACHE = "/workspace/token_cache"
CKPT_DIR    = "/workspace/checkpoints"
SUITE_DIR   = "/workspace/TestSuite"
PYEOF

# tmux
echo ""
echo "[tmux]"
command -v tmux &>/dev/null || apt-get install -q -y tmux
echo "  Use tmux for long runs — survives browser disconnect:"
echo "    tmux new -s primePE"
echo "    python runpod/run_suite.py --list"
echo "    Ctrl+B, D  (detach)"
echo "    tmux attach -t primePE  (reattach)"

echo ""
echo "============================================================"
echo "  Setup complete!"
echo "  cd /workspace/TestSuite && python runpod/run_suite.py --list"
echo "============================================================"
