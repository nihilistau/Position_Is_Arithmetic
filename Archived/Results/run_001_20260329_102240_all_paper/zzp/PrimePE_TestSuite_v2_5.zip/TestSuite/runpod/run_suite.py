#!/usr/bin/env python3
# TestSuite/runpod/run_suite.py
# Version: v2.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v2.0.0 — Complete RunPod experiment suite. All experiments defined here.
#             Auto-checkpoint, resume capability, VRAM-adaptive configs.
#
# Usage:
#   python runpod/run_suite.py --list
#   python runpod/run_suite.py --experiment zzp_full
#   python runpod/run_suite.py --experiment falsification_long
#   python runpod/run_suite.py --experiment g4_standard
#   python runpod/run_suite.py --experiment g4_harmonic
#   python runpod/run_suite.py --experiment g4_8k          # needs TurboQuant
#   python runpod/run_suite.py --experiment all_paper      # everything for paper
#   python runpod/run_suite.py --experiment resume --run-dir /workspace/results/run_XXX
# ──────────────────────────────────────────────────────────────────────────────

import argparse
import gc
import json
import math
import os
import sys
import time
from pathlib import Path

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

# ── Path setup ────────────────────────────────────────────────────────────────
SUITE_DIR  = Path(__file__).parent.parent
RUNPOD_DIR = Path(__file__).parent
sys.path.insert(0, str(SUITE_DIR))

# Try to import RunPod config, fall back to defaults
try:
    from runpod_config import RESULTS_DIR, TOKEN_CACHE, CKPT_DIR
except ImportError:
    RESULTS_DIR = "/workspace/results"
    TOKEN_CACHE = "/workspace/token_cache"
    CKPT_DIR    = "/workspace/checkpoints"

from shared.utils import setup_run_dir, setup_logger, save_json, print_banner, gpu_info
from shared.plots import plot_convergence, plot_ppl_vs_context, plot_gap_analysis

# ── GPU profile detection ─────────────────────────────────────────────────────

def detect_profile() -> dict:
    """Detect GPU and return appropriate training config."""
    if not torch.cuda.is_available():
        return {"name": "cpu", "vram_gb": 0, "profile": "cpu"}
    props  = torch.cuda.get_device_properties(0)
    vram   = props.total_memory / 1e9
    name   = props.name

    if vram >= 70:
        return {"name": name, "vram_gb": vram, "profile": "a100_80",
                "grad_accum": 32, "batch": 1, "workers": 4, "parallel": True}
    elif vram >= 40:
        return {"name": name, "vram_gb": vram, "profile": "a6000_48",
                "grad_accum": 32, "batch": 1, "workers": 4, "parallel": True}
    elif vram >= 20:
        return {"name": name, "vram_gb": vram, "profile": "rtx4090_24",
                "grad_accum": 64, "batch": 1, "workers": 2, "parallel": False}
    else:
        return {"name": name, "vram_gb": vram, "profile": "small",
                "grad_accum": 128, "batch": 1, "workers": 2, "parallel": False}


# ── Experiment catalogue ──────────────────────────────────────────────────────

def get_experiments() -> dict:
    gpu = detect_profile()
    parallel = gpu.get("parallel", True)

    # Base G4 config (matches paper exactly)
    G4 = {
        "d_model": 768, "n_heads": 12, "n_layers": 24, "ffn_dim": 3072,
        "dropout": 0.1, "vocab_size": 50257, "train_seq_len": 4096,
        "max_steps": 20000, "batch_size": 1, "grad_accum": gpu.get("grad_accum", 32),
        "lr": 3e-4, "warmup_steps": 1000, "eval_every": 500,
        "eval_ctx_lens": [512, 1024, 2048, 4096, 8192, 16384],
        "save_every": 2000,
    }

    # Falsification config (smaller model, designed to run multiple variants)
    FALS = {
        "d_model": 512, "n_heads": 8, "n_layers": 12, "ffn_dim": 2048,
        "dropout": 0.1, "vocab_size": 50257, "train_seq_len": 4096,
        "max_steps": 10000, "batch_size": 1, "grad_accum": gpu.get("grad_accum", 32),
        "lr": 3e-4, "warmup_steps": 1000, "eval_every": 500,
        "eval_ctx_lens": [512, 1024, 2048, 4096, 8192],
        "save_every": 2000,
    }

    return {

        # ── ZZP experiments ──────────────────────────────────────────────────
        "zzp_full": {
            "description": "ZetaZeroPredictor — full 10K epoch run (all 3 variants)",
            "type": "zzp",
            "epochs": 10000,
            "variants": ["geometric_rope", "spectral_alibi", "harmonic_string"],
            "cost_estimate": "~30 min, ~$0.70",
        },
        "zzp_extended": {
            "description": "ZetaZeroPredictor — 30K epochs (confirms long-run behaviour)",
            "type": "zzp",
            "epochs": 30000,
            "variants": ["geometric_rope", "spectral_alibi", "harmonic_string"],
            "cost_estimate": "~90 min, ~$2",
        },

        # ── Falsification experiments ────────────────────────────────────────
        "falsification_long": {
            "description": "Falsification suite — 10K steps, 4K context (THE key experiment)",
            "type": "falsification",
            "cfg": FALS,
            "variants": ["prime_tiered", "alibi", "scrambled_prime",
                         "random_freq", "composite_only"],
            "cost_estimate": "~3-4 hrs, ~$5-8",
            "why": "Tests whether prime structure separates from random at convergence",
        },
        "falsification_full": {
            "description": "Falsification suite — all 8 variants, 10K steps",
            "type": "falsification",
            "cfg": FALS,
            "variants": ["prime_tiered", "alibi", "geometric_rope",
                         "scrambled_prime", "random_freq", "composite_only",
                         "prime_noscale", "antiresonance"],
            "cost_estimate": "~6-8 hrs, ~$10-15",
            "why": "Complete falsification suite for paper",
        },

        # ── G4 equivalent experiments ────────────────────────────────────────
        "g4_standard": {
            "description": "G4 equivalent — 20K steps, 4K ctx, 4 core variants",
            "type": "g4",
            "cfg": G4,
            "variants": ["rope", "alibi", "spectral_rope", "spectral_rope_alibi"],
            "cost_estimate": "~4-5 hrs, ~$7-10",
            "why": "Reproduces main paper result with checkpoints saved safely",
        },
        "g4_harmonic": {
            "description": "G4 + harmonic variants — 20K steps, adds HS and HSALiBi",
            "type": "g4",
            "cfg": G4,
            "variants": ["rope", "alibi", "spectral_rope_alibi",
                         "harmonic_string", "harmonic_string_alibi"],
            "cost_estimate": "~6-7 hrs, ~$10-14",
            "why": "Completes harmonic string 20K run (session-terminated before)",
        },
        "g4_full": {
            "description": "Full suite — all 6 variants, 20K steps",
            "type": "g4",
            "cfg": G4,
            "variants": ["rope", "alibi", "spectral_rope", "spectral_rope_alibi",
                         "harmonic_string", "harmonic_string_alibi"],
            "cost_estimate": "~8-10 hrs, ~$14-20",
            "why": "Complete paper dataset in one run",
        },
        "g4_8k": {
            "description": "G4 with 8K training context — tests long-range prime heads",
            "type": "g4",
            "cfg": {**G4, "train_seq_len": 8192, "grad_accum": 64},
            "variants": ["rope", "alibi", "spectral_rope_alibi"],
            "cost_estimate": "~6-8 hrs, ~$12-16",
            "why": "Long-range prime heads need 8K+ context — predicted freq_scale divergence",
        },

        # ── Combined paper runs ──────────────────────────────────────────────
        "all_paper": {
            "description": "Everything needed for the paper — runs sequentially",
            "type": "sequence",
            "sequence": ["zzp_full", "falsification_long", "g4_harmonic"],
            "cost_estimate": "~12-14 hrs, ~$20-30",
            "why": "Complete paper dataset in one session",
        },
    }


# ── Checkpoint utilities ──────────────────────────────────────────────────────

def save_checkpoint(models: dict, step: int, run_dir: str, final: bool = False) -> None:
    """Save all model checkpoints. Uses /workspace/checkpoints for persistence."""
    tag = "final" if final else f"step{step:05d}"

    # Save to run dir (organized by run)
    ckpt_dir = os.path.join(run_dir, f"checkpoints_{tag}")
    os.makedirs(ckpt_dir, exist_ok=True)

    # Also save latest to /workspace/checkpoints (survives pod restart)
    persist_dir = os.path.join(CKPT_DIR, os.path.basename(run_dir))
    os.makedirs(persist_dir, exist_ok=True)

    for pe, model in models.items():
        raw = model._orig_mod if hasattr(model, "_orig_mod") else model
        sd  = raw.state_dict()

        # Run-local checkpoint
        torch.save(sd, os.path.join(ckpt_dir, f"ckpt_{pe}.pt"))

        # Persistent checkpoint (overwrites previous — always has latest)
        torch.save(sd, os.path.join(persist_dir, f"ckpt_{pe}_latest.pt"))
        if final:
            torch.save(sd, os.path.join(persist_dir, f"ckpt_{pe}_final.pt"))


def find_resume_checkpoint(run_dir: str) -> tuple[int, dict]:
    """Find the latest checkpoint in a run directory for resuming."""
    ckpt_dirs = sorted([
        d for d in os.listdir(run_dir)
        if d.startswith("checkpoints_step") and os.path.isdir(os.path.join(run_dir, d))
    ])
    if not ckpt_dirs:
        return 0, {}

    latest = os.path.join(run_dir, ckpt_dirs[-1])
    step   = int(ckpt_dirs[-1].replace("checkpoints_step", ""))
    pts    = {Path(f).stem.replace("ckpt_", ""): os.path.join(latest, f)
              for f in os.listdir(latest) if f.endswith(".pt")}
    return step, pts


# ── Training engine ───────────────────────────────────────────────────────────

def train_models(
    models: dict,
    cfg: dict,
    run_dir: str,
    log,
    start_step: int = 0,
) -> dict:
    """
    Core training loop. Handles all G4-style and falsification experiments.
    Saves checkpoints every cfg['save_every'] steps AND to persistent /workspace/checkpoints.
    """
    from pe_eval.data import tokenise_wikitext, ChunkDataset, make_eval_loader

    DEVICE   = "cuda" if torch.cuda.is_available() else "cpu"
    DTYPE    = torch.bfloat16 if torch.cuda.get_device_capability()[0] >= 8 \
               else torch.float16
    dev_type = "cuda" if DEVICE == "cuda" else "cpu"

    # Data
    log.info("Loading data...")
    chunks_tr = tokenise_wikitext("train",      cfg["train_seq_len"], TOKEN_CACHE)
    chunks_v  = tokenise_wikitext("validation", cfg["train_seq_len"], TOKEN_CACHE)
    tr_ds = ChunkDataset(chunks_tr)
    v_ds  = ChunkDataset(chunks_v)

    gpu    = detect_profile()
    n_work = gpu.get("workers", 2)
    tr_loader = DataLoader(tr_ds, batch_size=1, shuffle=True,
                           num_workers=n_work, drop_last=True, pin_memory=True)
    v_loader  = DataLoader(v_ds, batch_size=1, shuffle=False,
                           num_workers=min(n_work, 2), drop_last=True)
    log.info("Train: %d  Val: %d", len(tr_ds), len(v_ds))

    # Optimisers
    opts = {pe: torch.optim.AdamW(m.parameters(), lr=cfg["lr"], weight_decay=0.01)
            for pe, m in models.items()}

    def lr_fn(step):
        w = cfg["warmup_steps"]
        s = cfg["max_steps"]
        if step < w: return step / max(w, 1)
        t = (step - w) / max(s - w, 1)
        return 0.5 * (1 + math.cos(math.pi * t))

    scheds = {pe: torch.optim.lr_scheduler.LambdaLR(opts[pe], lr_fn)
              for pe in models}
    scaler = torch.cuda.amp.GradScaler()

    history = {pe: {"steps": [], "val_ppl": [], "val_loss": []} for pe in models}
    accum   = cfg.get("grad_accum", 32)
    step    = start_step
    t_start = time.time()
    save_every = cfg.get("save_every", 2000)

    # Fast-forward LR scheduler to resume step
    if start_step > 0:
        log.info("Resuming from step %d — fast-forwarding LR schedule...", start_step)
        for pe in models:
            for _ in range(start_step):
                scheds[pe].step()

    for m in models.values():
        m.train()

    data_iter = iter(tr_loader)

    while step < cfg["max_steps"]:

        # Gradient accumulation
        for _ in range(accum):
            try:
                x, y = next(data_iter)
            except StopIteration:
                data_iter = iter(tr_loader)
                x, y = next(data_iter)
            x, y = x.to(DEVICE), y.to(DEVICE)

            for pe, model in models.items():
                with torch.autocast(device_type=dev_type, dtype=DTYPE):
                    logits = model(x)
                    loss   = F.cross_entropy(
                        logits.reshape(-1, cfg["vocab_size"]),
                        y.reshape(-1)) / accum
                scaler.scale(loss).backward()

        for pe in models:
            scaler.unscale_(opts[pe])
            torch.nn.utils.clip_grad_norm_(models[pe].parameters(), 1.0)
            scaler.step(opts[pe])
            opts[pe].zero_grad()
            scheds[pe].step()
        scaler.update()
        step += 1

        # ── Evaluation ────────────────────────────────────────────────────────
        if step % cfg["eval_every"] == 0 or step == cfg["max_steps"]:
            elapsed = time.time() - t_start
            lr_now  = opts[list(models.keys())[0]].param_groups[0]["lr"]
            log.info("Step %5d/%d | %.0fs | lr=%.2e",
                     step, cfg["max_steps"], elapsed, lr_now)

            for pe, model in models.items():
                model.eval()
                losses = []
                with torch.no_grad():
                    for i, (x, y) in enumerate(v_loader):
                        if i >= 80: break
                        x, y = x.to(DEVICE), y.to(DEVICE)
                        with torch.autocast(device_type=dev_type, dtype=DTYPE):
                            logits = model(x)
                        losses.append(F.cross_entropy(
                            logits.reshape(-1, cfg["vocab_size"]),
                            y.reshape(-1)).item())
                vl  = sum(losses) / max(len(losses), 1)
                ppl = math.exp(vl)
                history[pe]["steps"].append(step)
                history[pe]["val_loss"].append(round(vl, 5))
                history[pe]["val_ppl"].append(round(ppl, 2))
                log.info("  %-32s ppl=%7.1f", pe, ppl)
                model.train()

            # Save history after every eval
            save_json(history, os.path.join(run_dir, "training_history.json"))

        # ── Checkpoint save ───────────────────────────────────────────────────
        if step % save_every == 0 or step == cfg["max_steps"]:
            is_final = (step == cfg["max_steps"])
            save_checkpoint(models, step, run_dir, final=is_final)
            log.info("Checkpoints saved @ step %d%s", step,
                     " (FINAL)" if is_final else "")

    return history


# ── Degradation table ─────────────────────────────────────────────────────────

def run_degradation_table(
    models: dict, cfg: dict, run_dir: str, log
) -> dict:
    """Evaluate all models at multiple context lengths after training."""
    from pe_eval.data import make_eval_loader

    DEVICE   = "cuda" if torch.cuda.is_available() else "cpu"
    DTYPE    = torch.bfloat16 if torch.cuda.get_device_capability()[0] >= 8 \
               else torch.float16
    dev_type = "cuda" if DEVICE == "cuda" else "cpu"

    results = {}
    for pe, model in models.items():
        log.info("Degradation eval: %s", pe)
        model.eval()
        ppls = {}
        for ctx in cfg.get("eval_ctx_lens", [512, 1024, 2048, 4096, 8192]):
            loader = make_eval_loader("test", ctx, TOKEN_CACHE)
            losses = []
            with torch.no_grad():
                for i, (x, y) in enumerate(loader):
                    if i >= 80: break
                    x, y = x.to(DEVICE), y.to(DEVICE)
                    with torch.autocast(device_type=dev_type, dtype=DTYPE):
                        logits = model(x)
                    losses.append(F.cross_entropy(
                        logits.reshape(-1, cfg["vocab_size"]),
                        y.reshape(-1)).item())
            ppls[ctx] = round(math.exp(sum(losses)/max(len(losses),1)), 2)
            log.info("  ctx=%d ppl=%.1f", ctx, ppls[ctx])
        results[pe] = ppls
        del model; gc.collect()
        if torch.cuda.is_available(): torch.cuda.empty_cache()

    save_json(results, os.path.join(run_dir, "ppl_results.json"))
    return results


# ── Experiment runners ────────────────────────────────────────────────────────

def run_zzp(exp_cfg: dict, run_dir: str, log) -> None:
    """Run ZetaZeroPredictor experiment."""
    import sys
    sys.path.insert(0, str(SUITE_DIR))
    from config import ZZP_CONFIG, ZETA_ZEROS_CACHE
    from zzp.data import load_zeros, make_loaders, compute_gaps
    from zzp.models import make_model
    from zzp.train import train_zzp
    from zzp.eval import evaluate_all, get_predictions, compile_results, print_report
    from shared.plots import plot_zzp_convergence, plot_zzp_predictions, plot_zzp_gap_distribution

    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

    cfg = dict(ZZP_CONFIG)
    cfg["epochs"]   = exp_cfg["epochs"]
    cfg["variants"] = exp_cfg["variants"]

    zzp_dir = os.path.join(run_dir, "zzp")
    os.makedirs(zzp_dir, exist_ok=True)

    zeros = load_zeros(
        os.path.join(str(SUITE_DIR), "zeta_zeros_1000.json"),
        cfg["n_zeros"])
    gaps  = compute_gaps(zeros)
    plot_zzp_gap_distribution(gaps, os.path.join(zzp_dir, "gap_distribution.png"))

    train_loader, val_loader, gap_mean, gap_std = make_loaders(
        zeros, cfg["seq_len"], cfg["batch_size"], cfg["train_split"])

    models = {v: make_model(v, cfg).to(DEVICE) for v in cfg["variants"]}
    for v, m in models.items():
        log.info("  ZZP %-22s %d params", v, sum(p.numel() for p in m.parameters()))

    history = train_zzp(models, train_loader, val_loader,
                        cfg["epochs"], cfg["lr"], DEVICE, print_every=100)

    final_mse = evaluate_all(models, val_loader, DEVICE)
    pred_data = get_predictions(models, val_loader, DEVICE)

    # Save ZZP checkpoints persistently
    persist = os.path.join(CKPT_DIR, "zzp")
    os.makedirs(persist, exist_ok=True)
    for v, m in models.items():
        torch.save(m.state_dict(), os.path.join(persist, f"zzp_{v}.pt"))

    results = compile_results(history, final_mse, gap_mean, gap_std,
                               cfg["epochs"], cfg)
    save_json(results,  os.path.join(zzp_dir, "results.json"))
    save_json(history,  os.path.join(zzp_dir, "history.json"))

    plot_zzp_convergence(history, os.path.join(zzp_dir, "convergence.png"))
    actuals = list(pred_data.values())[0][1]
    plot_zzp_predictions(actuals,
                         {v: pred_data[v][0] for v in models},
                         gap_mean, gap_std,
                         os.path.join(zzp_dir, "predictions.png"))
    print_report(results)


def run_g4(exp_cfg: dict, run_dir: str, log) -> None:
    """Run G4-style language modelling experiment."""
    from pe_eval.models import PrimePEModel

    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
    cfg    = exp_cfg["cfg"]
    g4_dir = os.path.join(run_dir, "g4")
    os.makedirs(g4_dir, exist_ok=True)

    save_json(cfg, os.path.join(g4_dir, "config.json"))

    # Check for resume
    start_step, resume_ckpts = find_resume_checkpoint(g4_dir)
    if start_step > 0:
        log.info("Resuming from step %d", start_step)

    # Build models
    models = {}
    for pe in exp_cfg["variants"]:
        m = PrimePEModel(cfg, pe).to(DEVICE)
        if torch.cuda.is_available() and detect_profile()["vram_gb"] >= 40:
            m = torch.compile(m)
        if start_step > 0 and pe in resume_ckpts:
            state = torch.load(resume_ckpts[pe], map_location=DEVICE)
            raw   = m._orig_mod if hasattr(m, "_orig_mod") else m
            raw.load_state_dict(state, strict=False)
            log.info("  Resumed %-28s from step %d", pe, start_step)
        n = sum(p.numel() for p in m.parameters())
        log.info("  %-30s %10d params", pe, n)
        models[pe] = m

    # Train
    history = train_models(models, cfg, g4_dir, log, start_step=start_step)

    # Final eval
    log.info("Running degradation table...")
    ppl_results = run_degradation_table(models, cfg, g4_dir, log)

    # Plots
    plot_convergence(history, os.path.join(g4_dir, "convergence.png"))
    plot_ppl_vs_context(ppl_results, os.path.join(g4_dir, "ppl_vs_context.png"),
                        train_ctx=cfg["train_seq_len"])
    plot_gap_analysis(history, os.path.join(g4_dir, "gap_analysis.png"))

    # Print summary
    log.info("\n=== FINAL PPL SUMMARY ===")
    for pe, ppls in ppl_results.items():
        ctx_str = "  ".join(f"@{k//1024 if k>=1024 else k}{'K' if k>=1024 else ''}:{v:.1f}"
                            for k, v in ppls.items())
        log.info("  %-30s %s", pe, ctx_str)


def run_falsification(exp_cfg: dict, run_dir: str, log) -> None:
    """Run falsification experiment."""
    from falsification.models import make_model, VARIANTS
    from falsification.train_eval import eval_ppl_at_contexts
    from freq_analysis.plots import plot_falsification_convergence
    from shared.plots import plot_ppl_vs_context

    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
    DTYPE  = torch.bfloat16 if torch.cuda.get_device_capability()[0] >= 8 \
             else torch.float16

    cfg     = exp_cfg["cfg"]
    f_dir   = os.path.join(run_dir, "falsification")
    os.makedirs(f_dir, exist_ok=True)

    save_json(cfg, os.path.join(f_dir, "config.json"))

    models = {}
    for v in exp_cfg["variants"]:
        m = make_model(v, cfg).to(DEVICE)
        n = sum(p.numel() for p in m.parameters())
        log.info("  %-38s %8d params", VARIANTS.get(v, v)[:38], n)
        models[v] = m

    from pe_eval.data import tokenise_wikitext, ChunkDataset
    chunks_tr = tokenise_wikitext("train",      cfg["train_seq_len"], TOKEN_CACHE)
    chunks_v  = tokenise_wikitext("validation", cfg["train_seq_len"], TOKEN_CACHE)
    tr_loader = DataLoader(ChunkDataset(chunks_tr), batch_size=1,
                           shuffle=True, num_workers=2, drop_last=True)
    v_loader  = DataLoader(ChunkDataset(chunks_v), batch_size=1,
                           shuffle=False, num_workers=2, drop_last=True)

    history = train_models(models, cfg, f_dir, log)
    ppl_results = eval_ppl_at_contexts(
        models, cfg.get("eval_ctx_lens", [512,1024,2048,4096,8192]),
        TOKEN_CACHE, DEVICE, DTYPE)

    save_json(history,     os.path.join(f_dir, "training_history.json"))
    save_json(ppl_results, os.path.join(f_dir, "ppl_results.json"))

    plot_falsification_convergence(history, os.path.join(f_dir, "convergence.png"))
    plot_ppl_vs_context(ppl_results, os.path.join(f_dir, "ppl_vs_context.png"),
                        train_ctx=cfg["train_seq_len"])

    # Interpretation
    finals = {v: h["val_ppl"][-1] if h["val_ppl"] else float("inf")
              for v, h in history.items()}
    prime  = finals.get("prime_tiered", float("inf"))
    log.info("\n=== FALSIFICATION RESULTS ===")
    log.info("prime_tiered final PPL: %.1f", prime)
    for v, f in sorted(finals.items(), key=lambda x: x[1]):
        diff = f - prime
        verdict = "SUPPORTS" if diff > 2 else ("NEUTRAL" if diff > -2 else "AGAINST")
        log.info("  %s  %-36s %.1f PPL (%+.1f)", verdict, v, f, diff)


# ── Main ──────────────────────────────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(description="PrimePE RunPod Suite")
    p.add_argument("--list", action="store_true", help="List all experiments")
    p.add_argument("--experiment", "-e", type=str, help="Experiment to run")
    p.add_argument("--resume", type=str, default=None,
                   help="Run dir to resume from")
    return p.parse_args()


def main():
    args   = parse_args()
    exps   = get_experiments()
    gpu    = detect_profile()

    if args.list:
        print(f"\n{'='*65}")
        print(f"  PrimePE RunPod Experiments")
        print(f"  GPU: {gpu['name']} ({gpu.get('vram_gb', 0):.0f}GB)")
        print(f"{'='*65}")
        for name, exp in exps.items():
            print(f"\n  {name}")
            print(f"    {exp['description']}")
            print(f"    Cost: {exp.get('cost_estimate', 'unknown')}")
            if "why" in exp:
                print(f"    Why:  {exp['why']}")
        print(f"\n  Run with: python runpod/run_suite.py --experiment <name>")
        print()
        return

    if not args.experiment:
        print("Use --list to see available experiments, or --experiment <name>")
        return

    exp_name = args.experiment
    if exp_name not in exps:
        print(f"Unknown experiment: {exp_name}")
        print(f"Available: {list(exps.keys())}")
        return

    exp = exps[exp_name]

    # Setup run directory
    run_dir = setup_run_dir(RESULTS_DIR, prefix=exp_name)
    log     = setup_logger(run_dir, "primePE.runpod")

    print_banner(f"RunPod: {exp_name}")
    log.info("Experiment: %s", exp["description"])
    log.info("GPU: %s (%.0f GB)", gpu["name"], gpu.get("vram_gb", 0))
    log.info("Run dir: %s", run_dir)
    log.info("Checkpoints: %s", CKPT_DIR)
    log.info("Cost estimate: %s", exp.get("cost_estimate", "unknown"))

    save_json({"experiment": exp_name, "gpu": gpu,
               "description": exp["description"]},
              os.path.join(run_dir, "experiment_info.json"))

    t_start = time.time()

    # Dispatch
    if exp["type"] == "zzp":
        run_zzp(exp, run_dir, log)

    elif exp["type"] == "g4":
        run_g4(exp, run_dir, log)

    elif exp["type"] == "falsification":
        run_falsification(exp, run_dir, log)

    elif exp["type"] == "sequence":
        log.info("Running sequence: %s", exp["sequence"])
        for sub_name in exp["sequence"]:
            sub_exp = exps[sub_name]
            log.info("\n%s STARTING: %s %s", "="*20, sub_name, "="*20)
            if sub_exp["type"] == "zzp":
                run_zzp(sub_exp, run_dir, log)
            elif sub_exp["type"] == "g4":
                run_g4(sub_exp, run_dir, log)
            elif sub_exp["type"] == "falsification":
                run_falsification(sub_exp, run_dir, log)

    elapsed = time.time() - t_start
    log.info("\nTotal runtime: %.0f seconds (%.1f hours)",
             elapsed, elapsed / 3600)
    log.info("Results: %s", run_dir)
    log.info("Checkpoints: %s", os.path.join(CKPT_DIR, os.path.basename(run_dir)))


if __name__ == "__main__":
    main()
