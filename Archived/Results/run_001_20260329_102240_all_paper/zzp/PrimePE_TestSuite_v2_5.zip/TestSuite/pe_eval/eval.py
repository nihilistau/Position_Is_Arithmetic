# TestSuite/pe_eval/eval.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. Checkpoint loading, PPL eval, degradation table.
#             Memory-efficient: loads one model at a time (RTX 2060 safe).
# ──────────────────────────────────────────────────────────────────────────────

from __future__ import annotations
import gc
import logging
import math
import os

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

log = logging.getLogger("primePE")


def eval_ppl(
    model: torch.nn.Module,
    loader: DataLoader,
    device: str,
    dtype: torch.dtype,
    n_batches: int = 80,
) -> float:
    """
    Evaluate perplexity on a DataLoader.

    Args:
        model:     Loaded model in eval mode.
        loader:    DataLoader of (x, y) token pairs.
        device:    "cuda" or "cpu".
        dtype:     bfloat16 or float16 for autocast.
        n_batches: Max batches to evaluate (more = more accurate, slower).

    Returns:
        Perplexity (float).
    """
    model.eval()
    losses = []
    with torch.no_grad():
        for i, (x, y) in enumerate(loader):
            if i >= n_batches:
                break
            x, y = x.to(device), y.to(device)
            device_type = "cuda" if device.startswith("cuda") else "cpu"
            with torch.autocast(device_type=device_type, dtype=dtype):
                logits = model(x)
            loss = F.cross_entropy(
                logits.reshape(-1, logits.size(-1)), y.reshape(-1))
            losses.append(loss.item())
    return math.exp(sum(losses) / max(len(losses), 1))


def load_checkpoint(
    ckpt_path: str,
    pe_name: str,
    cfg: dict,
    device: str,
) -> torch.nn.Module:
    """
    Load a PrimePEModel from a checkpoint file.

    Args:
        ckpt_path: Path to .pt file.
        pe_name:   PE variant name (e.g. "spectral_rope_alibi").
        cfg:       Model config dict.
        device:    Target device.

    Returns:
        Model in eval mode, on device.
    """
    from pe_eval.models import PrimePEModel

    model = PrimePEModel(cfg, pe_name).to(device)
    state = torch.load(ckpt_path, map_location=device)

    # Normalise keys — handle torch.compile wrapper and Colab naming differences
    clean = {}
    for k, v in state.items():
        nk = k.replace("_orig_mod.", "")
        nk = nk.replace("head.weight", "lm_head.weight")
        nk = nk.replace("head.bias",   "lm_head.bias")
        nk = nk.replace("lm_lm_head",  "lm_head")
        clean[nk] = v
    missing, unexpected = model.load_state_dict(clean, strict=False)
    if missing:
        log.warning("%s — missing keys: %s", pe_name, missing[:3])

    model.eval()
    log.info("Loaded checkpoint: %s (%s)", os.path.basename(ckpt_path), pe_name)
    return model


def run_degradation_table(
    checkpoint_dir: str,
    ckpt_to_pe: dict[str, str],
    cfg: dict,
    eval_ctx_lens: list[int],
    cache_dir: str,
    device: str,
    dtype: torch.dtype,
    n_batches: int = 80,
) -> dict[str, dict[int, float]]:
    """
    Load each checkpoint and evaluate PPL at multiple context lengths.
    Loads one model at a time to save VRAM (RTX 2060 friendly).

    Args:
        checkpoint_dir: Directory containing .pt files.
        ckpt_to_pe:     {checkpoint_stem: pe_name} mapping.
        cfg:            Model config dict.
        eval_ctx_lens:  List of context lengths to evaluate.
        cache_dir:      Token cache directory.
        device:         Target device.
        dtype:          Autocast dtype.
        n_batches:      Batches per eval.

    Returns:
        {pe_name: {ctx_len: ppl}}
    """
    from pe_eval.data import make_eval_loader

    results: dict[str, dict[int, float]] = {}

    for ckpt_stem, pe_name in ckpt_to_pe.items():
        ckpt_path = os.path.join(checkpoint_dir, f"{ckpt_stem}.pt")
        if not os.path.exists(ckpt_path):
            log.warning("Checkpoint not found: %s — skipping", ckpt_path)
            continue

        log.info("Evaluating: %s", pe_name)
        model = load_checkpoint(ckpt_path, pe_name, cfg, device)

        ppls: dict[int, float] = {}
        for ctx in eval_ctx_lens:
            log.info("  ctx=%d...", ctx)
            loader = make_eval_loader("test", ctx, cache_dir)
            ppl    = eval_ppl(model, loader, device, dtype, n_batches)
            ppls[ctx] = round(ppl, 3)
            log.info("  ctx=%d  PPL=%.2f", ctx, ppl)

        results[pe_name] = ppls

        # Free VRAM between models
        del model
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    return results


def compile_degradation_results(
    ppl_results: dict[str, dict[int, float]],
    cfg: dict,
    checkpoint_dir: str,
) -> dict:
    """Build the degradation_results.json output."""
    summary = {}
    for pe, ppls in ppl_results.items():
        ctx_list = sorted(ppls.keys())
        base     = ppls.get(ctx_list[0], 0)
        top      = ppls.get(ctx_list[-1], base)
        delta_pct = (top - base) / max(base, 1e-8) * 100
        summary[pe] = {
            "ppl_by_ctx": ppls,
            "delta_pct":  round(delta_pct, 2),
        }
    return {
        "model_cfg":      cfg,
        "checkpoint_dir": checkpoint_dir,
        "eval_ctx_lens":  sorted({c for d in ppl_results.values() for c in d}),
        "results":        summary,
    }


def print_degradation_report(results: dict) -> None:
    """Print degradation table to console."""
    ctx_lens = results["eval_ctx_lens"]
    ctx_lbl  = {512:"@512",1024:"@1K",2048:"@2K",4096:"@4K",
                8192:"@8K",16384:"@16K"}

    print()
    print("=" * 80)
    print("PPL DEGRADATION TABLE")
    print("=" * 80)
    hdrs = ["PE"] + [ctx_lbl.get(c, f"@{c}") for c in ctx_lens] + ["Δ%"]
    widths = [26] + [8] * len(ctx_lens) + [9]
    hdr_line = "  ".join(h.ljust(w) for h, w in zip(hdrs, widths))
    print(hdr_line)
    print("-" * 80)
    for pe, data in results["results"].items():
        ppls = data["ppl_by_ctx"]
        row  = [pe]
        for c in ctx_lens:
            row.append(f"{ppls.get(c, float('nan')):.1f}")
        row.append(f"{data['delta_pct']:+.1f}%")
        print("  ".join(str(v).ljust(w) for v, w in zip(row, widths)))
    print()
    print("Δ% = (PPL@max_ctx − PPL@512) / PPL@512 × 100")
    print("=" * 80)
