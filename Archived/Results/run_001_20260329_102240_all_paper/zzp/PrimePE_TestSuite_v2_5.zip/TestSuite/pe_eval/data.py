# TestSuite/pe_eval/data.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. WikiText-103 loading with Drive-compatible token cache.
#             Windows-safe (num_workers=0, module-level ChunkDataset).
# ──────────────────────────────────────────────────────────────────────────────

from __future__ import annotations
import logging
import os

import torch
from torch.utils.data import Dataset, DataLoader

log = logging.getLogger("primePE")


# ── Module-level Dataset (required for Windows pickle) ───────────────────────

class ChunkDataset(Dataset):
    """Fixed-length chunk dataset. chunks[i] = (seq_len+1,) token tensor."""

    def __init__(self, chunks: torch.Tensor) -> None:
        self.chunks = chunks

    def __len__(self) -> int:
        return len(self.chunks)

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, torch.Tensor]:
        chunk = self.chunks[idx]
        return chunk[:-1], chunk[1:]


def tokenise_wikitext(
    split: str,
    seq_len: int,
    cache_dir: str,
    max_tokens: int = 4_000_000,
) -> torch.Tensor:
    """
    Tokenise WikiText-103 and return chunks of (seq_len+1,) tokens.
    Results cached to cache_dir/wt103_{split}_{seq_len}.pt.

    Args:
        split: "train" | "validation" | "test"
        seq_len: Token sequence length per chunk.
        cache_dir: Directory for token cache files.
        max_tokens: Cap on total tokens (prevents OOM on load).

    Returns:
        (N, seq_len+1) int64 tensor.
    """
    os.makedirs(cache_dir, exist_ok=True)
    cache_path = os.path.join(cache_dir, f"wt103_{split}_{seq_len}.pt")

    if os.path.exists(cache_path):
        log.info("Loading token cache: %s", cache_path)
        return torch.load(cache_path, map_location="cpu")

    log.info("Tokenising WikiText-103 %s (seq_len=%d)...", split, seq_len)

    from transformers import GPT2TokenizerFast
    from datasets import load_dataset

    tokeniser = GPT2TokenizerFast.from_pretrained("gpt2")
    tokeniser.pad_token = tokeniser.eos_token

    ds   = load_dataset("wikitext", "wikitext-103-raw-v1", split=split)
    text = "\n\n".join(ds["text"])

    # Tokenise in rows to avoid OOM
    all_ids: list[int] = []
    rows = text.split("\n")
    for row in rows:
        row = row.strip()
        if not row:
            continue
        ids = tokeniser.encode(row, add_special_tokens=False)
        all_ids.extend(ids)
        if len(all_ids) >= max_tokens:
            all_ids = all_ids[:max_tokens]
            break

    # Chunk
    chunk_len = seq_len + 1
    n_chunks  = len(all_ids) // chunk_len
    ids_t     = torch.tensor(all_ids[:n_chunks * chunk_len], dtype=torch.int64)
    chunks    = ids_t.reshape(n_chunks, chunk_len)

    torch.save(chunks, cache_path)
    log.info("Tokenised %d tokens -> %d chunks -> saved to %s",
             len(all_ids), n_chunks, cache_path)
    return chunks


def make_eval_loader(
    split: str,
    seq_len: int,
    cache_dir: str,
    batch_size: int = 1,
) -> DataLoader:
    """Build an evaluation DataLoader for a given context length."""
    chunks = tokenise_wikitext(split, seq_len, cache_dir)
    ds     = ChunkDataset(chunks)
    return DataLoader(ds, batch_size=batch_size, shuffle=False,
                      num_workers=0, drop_last=True)
