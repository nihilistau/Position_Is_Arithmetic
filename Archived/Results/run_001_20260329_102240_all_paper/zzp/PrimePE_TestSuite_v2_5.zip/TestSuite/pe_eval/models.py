# TestSuite/pe_eval/models.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. Full PrimePEModel with all attention variants.
#             Matches checkpoint architecture exactly (G4 run, 300M params).
# ──────────────────────────────────────────────────────────────────────────────
# ──── Imports ────────────────────────────────────────────────────────────────

from __future__ import annotations
import math
import sys
import os
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from shared.primes import (
    get_primes, harmonic_resonance_matrix, spectral_rope_freqs
)

# ──── AdditivePE ─────────────────────────────────────────────────────────────

class AdditivePE(nn.Module):
    """Additive sinusoidal-style PE with arbitrary frequency set."""

    def __init__(self, d_model: int, freqs: torch.Tensor,
                 max_len: int = 65536, learnable: bool = False) -> None:
        super().__init__()
        pos  = torch.arange(max_len).unsqueeze(1).float()
        half = freqs.shape[0]
        pe   = torch.zeros(1, max_len, d_model)
        for i, f in enumerate(freqs):
            if 2 * i < d_model:
                pe[0, :, 2 * i]     = torch.sin(pos.squeeze() * f)
            if 2 * i + 1 < d_model:
                pe[0, :, 2 * i + 1] = torch.cos(pos.squeeze() * f)
        if learnable:
            self.pe = nn.Parameter(pe)
        else:
            self.register_buffer("pe", pe)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.pe[:, :x.size(1)]


# ──── Attention ──────────────────────────────────────────────────────────────

class Attention(nn.Module):
    """Standard attention with SDPA / ALiBi support."""

    def __init__(self, d_model: int, n_heads: int, dropout: float,
                 use_alibi: bool = False) -> None:
        super().__init__()
        self.n_heads  = n_heads
        self.head_dim = d_model // n_heads
        self.scale    = self.head_dim ** -0.5
        self.use_alibi = use_alibi
        self.qkv  = nn.Linear(d_model, 3 * d_model, bias=False)
        self.proj = nn.Linear(d_model, d_model, bias=False)
        self.drop = nn.Dropout(dropout)

        if use_alibi:
            slopes = torch.tensor(
                [2 ** (-8 * (h + 1) / n_heads) for h in range(n_heads)],
                dtype=torch.float32)
            self.register_buffer("alibi_slopes", slopes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape
        qkv = self.qkv(x).reshape(B, T, 3, self.n_heads, self.head_dim)
        q, k, v = qkv.permute(2, 0, 3, 1, 4).unbind(0)

        if self.use_alibi:
            scores = (q @ k.transpose(-2, -1)) * self.scale
            pos    = torch.arange(T, device=x.device, dtype=x.dtype)
            dist   = (pos.unsqueeze(0) - pos.unsqueeze(1)).abs()
            bias   = (-self.alibi_slopes.view(1, self.n_heads, 1, 1)
                      * dist.unsqueeze(0).unsqueeze(0))
            causal = torch.triu(
                torch.full((T, T), float("-inf"), device=x.device,
                           dtype=scores.dtype), 1)
            w = (scores + bias + causal).softmax(-1)
            out = (self.drop(w) @ v).transpose(1, 2).reshape(B, T, C)
        else:
            out = F.scaled_dot_product_attention(q, k, v, is_causal=True,
                                                 dropout_p=0.0)
            out = out.transpose(1, 2).reshape(B, T, C)

        return self.proj(out)


# ──── SpectralRoPEAttention ───────────────────────────────────────────────────

class SpectralRoPEAttention(nn.Module):
    """Tiered per-head prime rotations."""

    def __init__(self, d_model: int, n_heads: int, dropout: float,
                 head_freqs: torch.Tensor) -> None:
        super().__init__()
        self.n_heads  = n_heads
        self.head_dim = d_model // n_heads
        self.scale    = self.head_dim ** -0.5
        self.qkv  = nn.Linear(d_model, 3 * d_model, bias=False)
        self.proj = nn.Linear(d_model, d_model, bias=False)
        self.drop = nn.Dropout(dropout)
        self.register_buffer("head_freqs", head_freqs)
        self.freq_scale = nn.Parameter(torch.ones(n_heads))

    def _apply_rope(self, x: torch.Tensor) -> torch.Tensor:
        B, H, T, D = x.shape
        t  = torch.arange(T, device=x.device, dtype=x.dtype)
        sf = (self.head_freqs[:, :D // 2]
              * self.freq_scale.abs().unsqueeze(1)).to(x.dtype)
        ph = torch.einsum("t,hd->htd", t, sf)
        c, s  = ph.cos().unsqueeze(0), ph.sin().unsqueeze(0)
        x1, x2 = x[..., 0::2], x[..., 1::2]
        return torch.stack([x1 * c - x2 * s, x1 * s + x2 * c], -1).flatten(-2)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape
        qkv = self.qkv(x).reshape(B, T, 3, self.n_heads, self.head_dim)
        q, k, v = qkv.permute(2, 0, 3, 1, 4).unbind(0)
        q, k = self._apply_rope(q), self._apply_rope(k)
        out  = F.scaled_dot_product_attention(q, k, v, is_causal=True,
                                              dropout_p=0.0)
        return self.proj(out.transpose(1, 2).reshape(B, T, C))


# ──── SpectralALiBiAttention ──────────────────────────────────────────────────

class SpectralALiBiAttention(nn.Module):
    """Prime rotations + learned ALiBi bias + learned QK blend."""

    def __init__(self, d_model: int, n_heads: int, dropout: float,
                 head_freqs: torch.Tensor) -> None:
        super().__init__()
        self.n_heads  = n_heads
        self.head_dim = d_model // n_heads
        self.scale    = self.head_dim ** -0.5
        self.qkv  = nn.Linear(d_model, 3 * d_model, bias=False)
        self.proj = nn.Linear(d_model, d_model, bias=False)
        self.drop = nn.Dropout(dropout)
        self.register_buffer("head_freqs", head_freqs)
        self.freq_scale = nn.Parameter(torch.ones(n_heads))
        alibi_init = torch.tensor(
            [2 ** (-8 * (h + 1) / n_heads) for h in range(n_heads)],
            dtype=torch.float32)
        self.slopes = nn.Parameter(alibi_init)

    def _apply_rope(self, x: torch.Tensor) -> torch.Tensor:
        B, H, T, D = x.shape
        t  = torch.arange(T, device=x.device, dtype=x.dtype)
        sf = (self.head_freqs[:, :D // 2]
              * self.freq_scale.abs().unsqueeze(1)).to(x.dtype)
        ph = torch.einsum("t,hd->htd", t, sf)
        c, s  = ph.cos().unsqueeze(0), ph.sin().unsqueeze(0)
        x1, x2 = x[..., 0::2], x[..., 1::2]
        return torch.stack([x1 * c - x2 * s, x1 * s + x2 * c], -1).flatten(-2)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape
        qkv = self.qkv(x).reshape(B, T, 3, self.n_heads, self.head_dim)
        q, k, v = qkv.permute(2, 0, 3, 1, 4).unbind(0)
        q, k   = self._apply_rope(q), self._apply_rope(k)
        scores = (q @ k.transpose(-2, -1)) * self.scale
        pos    = torch.arange(T, device=x.device, dtype=x.dtype)
        dist   = (pos.unsqueeze(0) - pos.unsqueeze(1)).abs()
        alibi  = (-self.slopes.abs().view(1, self.n_heads, 1, 1)
                  * dist.unsqueeze(0).unsqueeze(0))
        causal = torch.triu(
            torch.full((T, T), float("-inf"), device=x.device,
                       dtype=scores.dtype), 1)
        w   = (scores + alibi + causal).softmax(-1)
        out = (self.drop(w) @ v).transpose(1, 2).reshape(B, T, C)
        return self.proj(out)


# ──── HarmonicStringAttention ─────────────────────────────────────────────────

class HarmonicStringAttention(nn.Module):
    """Attention score = prime harmonic resonance + QK."""

    def __init__(self, d_model: int, n_heads: int, dropout: float,
                 n_primes: int = 64) -> None:
        super().__init__()
        self.n_heads  = n_heads
        self.head_dim = d_model // n_heads
        self.scale    = self.head_dim ** -0.5
        self.n_primes = n_primes
        self.qkv  = nn.Linear(d_model, 3 * d_model, bias=False)
        self.proj = nn.Linear(d_model, d_model, bias=False)
        self.drop = nn.Dropout(dropout)
        self.head_alpha = nn.Parameter(torch.ones(n_heads))
        self.head_beta  = nn.Parameter(torch.ones(n_heads))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape
        qkv = self.qkv(x).reshape(B, T, 3, self.n_heads, self.head_dim)
        q, k, v = qkv.permute(2, 0, 3, 1, 4).unbind(0)
        qk     = (q @ k.transpose(-2, -1)) * self.scale
        R      = harmonic_resonance_matrix(T, self.n_primes).to(
            x.device, x.dtype).unsqueeze(0).unsqueeze(0)
        ha     = self.head_alpha.abs().view(1, self.n_heads, 1, 1)
        hb     = self.head_beta.abs().view(1, self.n_heads, 1, 1)
        causal = torch.triu(
            torch.full((T, T), float("-inf"), device=x.device,
                       dtype=qk.dtype), 1)
        w      = (ha * R + hb * qk + causal).softmax(-1)
        out    = (self.drop(w) @ v).transpose(1, 2).reshape(B, T, C)
        return self.proj(out)


class HarmonicStringALiBiAttention(nn.Module):
    """Harmonic resonance + ALiBi distance bias + QK."""

    def __init__(self, d_model: int, n_heads: int, dropout: float,
                 n_primes: int = 64) -> None:
        super().__init__()
        self.n_heads  = n_heads
        self.head_dim = d_model // n_heads
        self.scale    = self.head_dim ** -0.5
        self.n_primes = n_primes
        self.qkv  = nn.Linear(d_model, 3 * d_model, bias=False)
        self.proj = nn.Linear(d_model, d_model, bias=False)
        self.drop = nn.Dropout(dropout)
        self.head_alpha = nn.Parameter(torch.ones(n_heads))
        alibi_init = torch.tensor(
            [2 ** (-8 * (h + 1) / n_heads) for h in range(n_heads)],
            dtype=torch.float32)
        self.slopes    = nn.Parameter(alibi_init)
        self.head_beta = nn.Parameter(torch.ones(n_heads))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape
        qkv = self.qkv(x).reshape(B, T, 3, self.n_heads, self.head_dim)
        q, k, v = qkv.permute(2, 0, 3, 1, 4).unbind(0)
        qk     = (q @ k.transpose(-2, -1)) * self.scale
        R      = harmonic_resonance_matrix(T, self.n_primes).to(
            x.device, x.dtype).unsqueeze(0).unsqueeze(0)
        pos    = torch.arange(T, device=x.device, dtype=x.dtype)
        dist   = (pos.unsqueeze(0) - pos.unsqueeze(1)).abs()
        alibi  = (-self.slopes.abs().view(1, self.n_heads, 1, 1)
                  * dist.unsqueeze(0).unsqueeze(0))
        ha     = self.head_alpha.abs().view(1, self.n_heads, 1, 1)
        hb     = self.head_beta.abs().view(1, self.n_heads, 1, 1)
        causal = torch.triu(
            torch.full((T, T), float("-inf"), device=x.device,
                       dtype=qk.dtype), 1)
        w   = (ha * R + alibi + hb * qk + causal).softmax(-1)
        out = (self.drop(w) @ v).transpose(1, 2).reshape(B, T, C)
        return self.proj(out)


# ──── Block ───────────────────────────────────────────────────────────────────

class Block(nn.Module):
    def __init__(self, d_model: int, n_heads: int, ffn_dim: int,
                 dropout: float, attn: nn.Module) -> None:
        super().__init__()
        self.attn  = attn
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.ffn   = nn.Sequential(
            nn.Linear(d_model, ffn_dim), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(ffn_dim, d_model), nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.norm1(x))
        x = x + self.ffn(self.norm2(x))
        return x


# ──── PrimePEModel ────────────────────────────────────────────────────────────

class PrimePEModel(nn.Module):
    """
    Full language model matching the G4 checkpoint architecture.
    Supports all PE variants: rope, alibi, spectral_rope, spectral_rope_alibi,
    harmonic_string, harmonic_string_alibi.
    """

    def __init__(self, cfg: dict, pe_name: str) -> None:
        super().__init__()
        self.cfg     = cfg
        self.pe_name = pe_name

        d      = cfg["d_model"]
        nh     = cfg["n_heads"]
        nl     = cfg["n_layers"]
        ffn    = cfg["ffn_dim"]
        dr     = cfg["dropout"]
        vocab  = cfg["vocab_size"]

        self.embed = nn.Embedding(vocab, d)
        self.drop  = nn.Dropout(dr)
        self.norm  = nn.LayerNorm(d)
        self.lm_head = nn.Linear(d, vocab, bias=False)
        self.embed.weight = self.lm_head.weight  # weight tying

        # PE / attention
        self.pe = None

        if pe_name == "rope":
            geo_f = (1.0 / (10000 ** (torch.arange(0, d // nh, 2).float()
                                       / (d // nh))))
            self.blocks = nn.ModuleList([
                Block(d, nh, ffn, dr, Attention(d, nh, dr)) for _ in range(nl)
            ])
            self.register_buffer("rope_freqs", geo_f)

        elif pe_name == "alibi":
            self.blocks = nn.ModuleList([
                Block(d, nh, ffn, dr, Attention(d, nh, dr, use_alibi=True))
                for _ in range(nl)
            ])

        elif pe_name in ("spectral_rope", "spectral_rope_alibi"):
            hf = spectral_rope_freqs(d, nh)
            if pe_name == "spectral_rope":
                attn_cls = lambda: SpectralRoPEAttention(d, nh, dr, hf.clone())
            else:
                attn_cls = lambda: SpectralALiBiAttention(d, nh, dr, hf.clone())
            self.blocks = nn.ModuleList([
                Block(d, nh, ffn, dr, attn_cls()) for _ in range(nl)
            ])

        elif pe_name == "harmonic_string":
            self.blocks = nn.ModuleList([
                Block(d, nh, ffn, dr, HarmonicStringAttention(d, nh, dr, 64))
                for _ in range(nl)
            ])

        elif pe_name == "harmonic_string_alibi":
            self.blocks = nn.ModuleList([
                Block(d, nh, ffn, dr,
                      HarmonicStringALiBiAttention(d, nh, dr, 64))
                for _ in range(nl)
            ])

        else:
            raise ValueError(f"Unknown PE: {pe_name}")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.drop(self.embed(x))
        if self.pe is not None:
            x = self.pe(x)
        for block in self.blocks:
            x = block(x)
        return self.lm_head(self.norm(x))
