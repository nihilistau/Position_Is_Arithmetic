# TestSuite/freq_analysis/lll.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. LLL reduction of W_Q, W_K matrices.
#             Tests the LLL convergence theorem: if prime PE is correct,
#             trained weight matrices should converge toward LLL-reduced
#             bases of the prime lattice.
# ──────────────────────────────────────────────────────────────────────────────
#
# THE LLL TEST:
#   Hypothesis: W_Q, W_K from trained SpectralALiBi converge toward the
#   LLL-reduced basis of the prime lattice restricted to their frequency subspace.
#
#   Method:
#   1. Extract W_Q, W_K from a trained checkpoint.
#   2. Apply LLL reduction to get the shortest-vector basis.
#   3. Measure alignment between LLL basis vectors and prime frequency directions.
#   4. Compare alignment in SpectralALiBi vs geometric RoPE (control).
#
#   Falsification: if SpectralALiBi alignment is no better than geometric RoPE,
#   the LLL convergence theorem is wrong.
#
# ──────────────────────────────────────────────────────────────────────────────

from __future__ import annotations
import logging
import os
import sys

import torch
import numpy as np

log = logging.getLogger("primePE")


def _gram_schmidt(basis: np.ndarray) -> np.ndarray:
    """Basic Gram-Schmidt orthogonalisation."""
    n, d  = basis.shape
    orth  = np.zeros_like(basis, dtype=np.float64)
    mu    = np.zeros((n, n), dtype=np.float64)
    for i in range(n):
        orth[i] = basis[i].copy()
        for j in range(i):
            mu[i, j] = np.dot(basis[i], orth[j]) / max(np.dot(orth[j], orth[j]), 1e-15)
            orth[i] -= mu[i, j] * orth[j]
    return orth, mu


def lll_reduce(basis: np.ndarray, delta: float = 0.75) -> np.ndarray:
    """
    LLL lattice basis reduction (Lenstra-Lenstra-Lovász, 1982).
    Finds a nearly-orthogonal reduced basis.

    Args:
        basis: (n, d) float64 array — rows are lattice basis vectors.
        delta: LLL parameter (0.25 < delta < 1.0). 0.75 is standard.

    Returns:
        (n, d) LLL-reduced basis.
    """
    basis  = basis.astype(np.float64).copy()
    n      = len(basis)
    k      = 1

    while k < n:
        orth, mu = _gram_schmidt(basis)

        # Size reduction
        for j in range(k - 1, -1, -1):
            if abs(mu[k, j]) > 0.5:
                basis[k] -= round(mu[k, j]) * basis[j]
                orth, mu  = _gram_schmidt(basis)

        # Lovász condition
        orth_k   = orth[k]
        orth_km1 = orth[k - 1]
        lhs      = np.dot(orth_k, orth_k) + mu[k, k - 1] ** 2 * np.dot(orth_km1, orth_km1)
        rhs      = delta * np.dot(orth_km1, orth_km1)

        if lhs >= rhs:
            k += 1
        else:
            basis[[k, k - 1]] = basis[[k - 1, k]]
            k = max(k - 1, 1)

    return basis


def compute_prime_alignment(
    weight_matrix: torch.Tensor,
    head_freqs: torch.Tensor,
    n_heads: int,
    head_dim: int,
) -> dict:
    """
    Measure alignment between LLL-reduced weight matrix and prime frequency directions.

    Args:
        weight_matrix: (d_model, d_model) W_Q or W_K.
        head_freqs:    (n_heads, rope_half) prime frequencies for each head.
        n_heads:       Number of attention heads.
        head_dim:      Head dimension.

    Returns:
        Alignment statistics.
    """
    d_model  = weight_matrix.shape[0]
    rope_half = head_freqs.shape[1]
    W        = weight_matrix.float().cpu().numpy()

    # Build prime frequency direction vectors in W_Q space
    # Each head's frequency directions are unit vectors at 2π/p in R^{head_dim}
    prime_dirs = []
    for h in range(n_heads):
        for freq in head_freqs[h]:
            f = freq.item()
            # Cosine and sine directions for this frequency
            v = np.zeros(head_dim, dtype=np.float64)
            for d in range(0, head_dim - 1, 2):
                scale = f * (d // 2 + 1)
                v[d]     = np.cos(scale)
                v[d + 1] = np.sin(scale)
            norm = np.linalg.norm(v)
            if norm > 1e-10:
                prime_dirs.append(v / norm)

    if not prime_dirs:
        return {"error": "No prime directions generated"}

    prime_basis = np.array(prime_dirs[:min(d_model, len(prime_dirs))],
                           dtype=np.float64)

    # Apply LLL to a subset of W rows (full LLL is expensive)
    log.info("Applying LLL reduction to weight submatrix (%dx%d)...",
             min(d_model, 64), d_model)
    W_sub = W[:min(d_model, 64)]
    try:
        W_lll = lll_reduce(W_sub.copy())
    except Exception as e:
        log.warning("LLL failed: %s", e)
        return {"error": str(e)}

    # Measure alignment: cosine similarity between LLL basis and prime directions
    alignments = []
    for lll_vec in W_lll:
        norm = np.linalg.norm(lll_vec)
        if norm < 1e-10:
            continue
        lll_unit = lll_vec / norm
        sims = [abs(np.dot(lll_unit, pd)) for pd in prime_basis[:min(100, len(prime_basis))]]
        alignments.append(max(sims))  # best alignment with any prime direction

    alignment_mean = float(np.mean(alignments)) if alignments else 0.0
    alignment_max  = float(np.max(alignments))  if alignments else 0.0

    # Baseline: random matrix alignment
    rng = np.random.RandomState(42)
    rand_W = rng.randn(*W_sub.shape)
    rand_lll = lll_reduce(rand_W.copy())
    rand_alignments = []
    for lll_vec in rand_lll:
        norm = np.linalg.norm(lll_vec)
        if norm < 1e-10:
            continue
        lll_unit = lll_vec / norm
        sims = [abs(np.dot(lll_unit, pd)) for pd in prime_basis[:min(100, len(prime_basis))]]
        rand_alignments.append(max(sims))
    rand_mean = float(np.mean(rand_alignments)) if rand_alignments else 0.0

    improvement = (alignment_mean - rand_mean) / max(rand_mean, 1e-8) * 100

    return {
        "alignment_mean":    round(alignment_mean, 4),
        "alignment_max":     round(alignment_max, 4),
        "random_baseline":   round(rand_mean, 4),
        "improvement_pct":   round(improvement, 1),
        "n_vectors_tested":  len(alignments),
        "interpretation": (
            f"LLL basis vectors align with prime directions "
            f"{improvement:+.1f}% better than random. "
            + ("SUPPORTS LLL theorem." if improvement > 5 else
               "NEUTRAL — no strong alignment signal." if improvement > -5 else
               "AGAINST LLL theorem — geometric model may align better.")
        ),
    }


def run_lll_analysis(
    checkpoint_paths: dict[str, str],
    pe_cfg: dict,
    device: str = "cpu",
) -> dict:
    """
    Run LLL analysis on multiple checkpoints.

    Args:
        checkpoint_paths: {pe_name: ckpt_path}
        pe_cfg:           Model config.
        device:           Device (cpu recommended for analysis).

    Returns:
        {pe_name: alignment_results}
    """
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    from pe_eval.models import PrimePEModel
    from shared.primes import spectral_rope_freqs

    results = {}
    n_heads  = pe_cfg["n_heads"]
    d_model  = pe_cfg["d_model"]
    head_dim = d_model // n_heads
    hf       = spectral_rope_freqs(d_model, n_heads)

    for pe_name, ckpt_path in checkpoint_paths.items():
        if not os.path.exists(ckpt_path):
            log.warning("Checkpoint not found: %s", ckpt_path)
            continue

        log.info("LLL analysis: %s", pe_name)

        try:
            model = PrimePEModel(pe_cfg, pe_name)
            state = torch.load(ckpt_path, map_location="cpu")
            clean = {k.replace("_orig_mod.", ""): v for k, v in state.items()}
            model.load_state_dict(clean, strict=False)
            model.eval()

            # Extract first block W_Q and W_K
            first_block = model.blocks[0]
            W_qkv = first_block.attn.qkv.weight.data  # (3*d, d)
            W_Q   = W_qkv[:d_model]
            W_K   = W_qkv[d_model:2 * d_model]

            log.info("  Analysing W_Q (%dx%d)...", *W_Q.shape)
            results[f"{pe_name}_WQ"] = compute_prime_alignment(W_Q, hf, n_heads, head_dim)

            log.info("  Analysing W_K (%dx%d)...", *W_K.shape)
            results[f"{pe_name}_WK"] = compute_prime_alignment(W_K, hf, n_heads, head_dim)

            del model
        except Exception as e:
            log.error("LLL analysis failed for %s: %s", pe_name, e)
            results[pe_name] = {"error": str(e)}

    return results


def print_lll_report(results: dict) -> None:
    print()
    print("=" * 70)
    print("LLL WEIGHT MATRIX ANALYSIS")
    print("=" * 70)
    print(f"{'Model+Matrix':<32} {'Alignment':>10} {'Baseline':>10} {'Δ%':>8}")
    print("-" * 70)
    for name, r in results.items():
        if "error" in r:
            print(f"{name:<32} ERROR: {r['error'][:30]}")
        else:
            print(f"{name:<32} {r['alignment_mean']:>10.4f} "
                  f"{r['random_baseline']:>10.4f} {r['improvement_pct']:>+7.1f}%")
    print()
    print("Δ% = improvement over random matrix LLL alignment")
    print("Positive = weight matrix aligns with prime directions (supports theorem)")
    print("=" * 70)
