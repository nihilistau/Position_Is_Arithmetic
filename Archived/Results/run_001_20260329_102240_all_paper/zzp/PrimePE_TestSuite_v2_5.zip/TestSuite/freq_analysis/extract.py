# TestSuite/freq_analysis/extract.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. Extract freq_scale values from trained checkpoints.
#             Answers: what frequency basis did the model discover?
# ──────────────────────────────────────────────────────────────────────────────
#
# THE FREQ_SCALE QUESTION:
#   In RoPE, base=10000 is fixed. In SpectralALiBi, freq_scale is learned.
#   At convergence, freq_scale[h] tells us whether head h amplified (>1)
#   or suppressed (<1) its prime frequencies.
#
#   If prime PE is genuinely aligned with language structure, we expect:
#   - Local heads (small primes, syntax): freq_scale ~ 1.0-2.0
#   - Mid heads (medium primes, clauses): freq_scale ~ 0.5-1.5
#   - Long heads (large primes, sections): freq_scale ~ 0.1-0.8
#     (long-range heads may suppress at short training context)
#
# ──────────────────────────────────────────────────────────────────────────────

from __future__ import annotations
import logging
import os
import sys

import torch
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from shared.primes import spectral_rope_freqs, get_primes

log = logging.getLogger("primePE")


def extract_freq_scale(
    ckpt_path: str,
    pe_name: str,
    cfg: dict,
    device: str = "cpu",
) -> dict[str, torch.Tensor]:
    """
    Extract freq_scale parameters from a trained SpectralALiBi checkpoint.

    Args:
        ckpt_path: Path to .pt checkpoint file.
        pe_name:   PE variant (must be spectral_rope_alibi or spectral_rope).
        cfg:       Model config dict.
        device:    Where to load (cpu is fine for analysis).

    Returns:
        {
          "freq_scale_per_layer": (n_layers, n_heads) tensor,
          "freq_scale_mean":      (n_heads,) mean across layers,
          "freq_scale_std":       (n_heads,) std across layers,
          "alibi_slopes":         (n_layers, n_heads) learned ALiBi slopes,
          "effective_freqs":      (n_layers, n_heads, rope_half) actual frequencies,
        }
    """
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    from pe_eval.models import PrimePEModel

    log.info("Loading checkpoint: %s", os.path.basename(ckpt_path))
    model = PrimePEModel(cfg, pe_name)
    state = torch.load(ckpt_path, map_location=device)

    # Normalise keys — handle torch.compile wrapper and Colab naming differences
    clean = {}
    for k, v in state.items():
        nk = k.replace("_orig_mod.", "")
        # Colab training code used "head" not "lm_head"
        nk = nk.replace("head.weight", "lm_head.weight")
        nk = nk.replace("head.bias",   "lm_head.bias")
        # But don't accidentally rename lm_head.weight twice
        nk = nk.replace("lm_lm_head", "lm_head")
        clean[nk] = v

    missing, unexpected = model.load_state_dict(clean, strict=False)
    if missing:
        log.warning("Missing keys (first 5): %s", missing[:5])
    if unexpected:
        log.warning("Unexpected keys (first 5): %s", unexpected[:5])
    model.eval()

    n_heads    = cfg["n_heads"]
    d_model    = cfg["d_model"]
    rope_half  = (d_model // n_heads) // 2
    base_freqs = spectral_rope_freqs(d_model, n_heads)  # (n_heads, rope_half)

    freq_scales  = []
    alibi_slopes = []

    for block in model.blocks:
        attn = block.attn
        if hasattr(attn, "freq_scale"):
            fs = attn.freq_scale.data.abs().cpu()
            freq_scales.append(fs)
        if hasattr(attn, "slopes"):
            sl = attn.slopes.data.abs().cpu()
            alibi_slopes.append(sl)

    if not freq_scales:
        log.warning("No freq_scale found in checkpoint — is this a spectral model?")
        return {}

    fs_tensor = torch.stack(freq_scales)       # (n_layers, n_heads)
    sl_tensor = torch.stack(alibi_slopes) if alibi_slopes else None

    # Effective frequencies per head (using mean freq_scale across layers)
    fs_mean = fs_tensor.mean(0)                # (n_heads,)
    eff_freqs = base_freqs * fs_mean.unsqueeze(1)  # (n_heads, rope_half)

    return {
        "freq_scale_per_layer": fs_tensor,
        "freq_scale_mean":      fs_mean,
        "freq_scale_std":       fs_tensor.std(0),
        "alibi_slopes":         sl_tensor,
        "effective_freqs":      eff_freqs,
        "base_freqs":           base_freqs,
        "n_heads":              n_heads,
        "n_layers":             len(freq_scales),
    }


def analyse_freq_scale(data: dict) -> dict:
    """
    Analyse freq_scale data and produce a human-readable summary.

    Returns:
        Summary dict with tier breakdown and key observations.
    """
    n_heads  = data["n_heads"]
    n_layers = data["n_layers"]
    fs_mean  = data["freq_scale_mean"]  # (n_heads,)
    fs_std   = data["freq_scale_std"]

    n_local = max(1, n_heads // 4)
    n_mid   = max(1, n_heads // 3)
    n_long  = max(1, n_heads - n_local - n_mid)

    local_heads = list(range(0, n_local))
    mid_heads   = list(range(n_local, n_local + n_mid))
    long_heads  = list(range(n_local + n_mid, n_heads))

    def tier_stats(heads: list[int]) -> dict:
        vals = fs_mean[heads]
        return {
            "mean":  round(vals.mean().item(), 4),
            "std":   round(vals.std().item(), 4),
            "min":   round(vals.min().item(), 4),
            "max":   round(vals.max().item(), 4),
            "heads": heads,
        }

    tiers = {
        "local_syntax":     tier_stats(local_heads),
        "mid_clause":       tier_stats(mid_heads),
        "long_section":     tier_stats(long_heads),
    }

    # Key observation: did long-range heads get suppressed?
    # (expected if trained at 4K context — they haven't seen enough range)
    local_mean = tiers["local_syntax"]["mean"]
    long_mean  = tiers["long_section"]["mean"]
    suppressed = long_mean < local_mean * 0.5

    return {
        "tiers":           tiers,
        "overall_mean":    round(fs_mean.mean().item(), 4),
        "overall_std":     round(fs_mean.std().item(), 4),
        "long_suppressed": suppressed,
        "observation":     (
            f"Long-range heads suppressed (mean {long_mean:.3f} vs "
            f"local {local_mean:.3f}) — consistent with 4K training context "
            f"(long prime periods not fully utilised)."
            if suppressed else
            f"Long-range heads not suppressed (mean {long_mean:.3f} vs "
            f"local {local_mean:.3f}) — model is using full prime tier range."
        ),
    }


def print_freq_report(analysis: dict, pe_name: str) -> None:
    """Print freq_scale analysis to console."""
    print()
    print("=" * 65)
    print(f"FREQ_SCALE ANALYSIS — {pe_name}")
    print("=" * 65)
    print(f"Overall: mean={analysis['overall_mean']:.4f}  "
          f"std={analysis['overall_std']:.4f}")
    print()
    print(f"{'Tier':<20} {'Mean':>8} {'Std':>8} {'Min':>8} {'Max':>8}  Heads")
    print("-" * 65)
    for name, stats in analysis["tiers"].items():
        print(f"{name:<20} {stats['mean']:>8.4f} {stats['std']:>8.4f} "
              f"{stats['min']:>8.4f} {stats['max']:>8.4f}  "
              f"{stats['heads'][0]}..{stats['heads'][-1]}")
    print()
    print(f"Observation: {analysis['observation']}")
    print("=" * 65)
