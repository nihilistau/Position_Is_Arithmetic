# TestSuite/freq_analysis/plots.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. Visualisations for freq_scale and LLL analysis.
# ──────────────────────────────────────────────────────────────────────────────

from __future__ import annotations
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from config import PLOT_STYLE

BG   = PLOT_STYLE["bg"]
CYAN = PLOT_STYLE["cyan"]
GOLD = PLOT_STYLE["gold"]
PINK = PLOT_STYLE["pink"]
WHITE = PLOT_STYLE["white"]
GRID = PLOT_STYLE["grid"]
DPI  = PLOT_STYLE["dpi"]

plt.rcParams.update({
    "figure.facecolor": BG, "axes.facecolor": BG,
    "axes.edgecolor": GRID, "grid.color": GRID,
    "text.color": WHITE, "axes.labelcolor": WHITE,
    "xtick.color": WHITE, "ytick.color": WHITE,
    "legend.facecolor": "#1e2a3a", "legend.edgecolor": GRID,
    "font.family": "DejaVu Sans",
})


def _save(fig, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fig.savefig(path, dpi=DPI, facecolor=BG, bbox_inches="tight")
    plt.close(fig)


def plot_freq_scale_heatmap(data: dict, out_path: str, pe_name: str) -> None:
    """
    Heatmap of freq_scale values: (n_layers, n_heads).
    Shows which heads amplified vs suppressed their prime frequencies.
    """
    fs = data["freq_scale_per_layer"].numpy()  # (n_layers, n_heads)
    n_heads = data["n_heads"]
    n_local = max(1, n_heads // 4)
    n_mid   = max(1, n_heads // 3)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Heatmap
    im = axes[0].imshow(fs, aspect="auto", cmap="RdYlGn",
                         vmin=0.0, vmax=fs.max() * 1.1)
    axes[0].set_xlabel("Head", fontsize=11)
    axes[0].set_ylabel("Layer", fontsize=11)
    axes[0].set_title(f"freq_scale per layer/head\n({pe_name})",
                       fontsize=12, color=CYAN)
    plt.colorbar(im, ax=axes[0])

    # Tier boundaries
    for x in [n_local - 0.5, n_local + n_mid - 0.5]:
        axes[0].axvline(x, color=GOLD, linewidth=1.5, linestyle="--", alpha=0.7)
    axes[0].text(n_local // 2, -0.8, "Local", ha="center", color=GOLD, fontsize=8)
    axes[0].text(n_local + n_mid // 2, -0.8, "Mid", ha="center", color=GOLD, fontsize=8)
    axes[0].text(n_local + n_mid + (n_heads - n_local - n_mid) // 2, -0.8,
                 "Long", ha="center", color=GOLD, fontsize=8)

    # Mean per head across layers
    mean = data["freq_scale_mean"].numpy()
    std  = data["freq_scale_std"].numpy()
    axes[1].bar(range(n_heads), mean, color=[
        CYAN if h < n_local else (GOLD if h < n_local + n_mid else PINK)
        for h in range(n_heads)
    ], alpha=0.85)
    axes[1].errorbar(range(n_heads), mean, yerr=std,
                      fmt="none", color=WHITE, alpha=0.5, capsize=3)
    axes[1].axhline(1.0, color=WHITE, linewidth=0.8, linestyle="--", alpha=0.4,
                     label="init value")
    axes[1].set_xlabel("Head", fontsize=11)
    axes[1].set_ylabel("Mean freq_scale", fontsize=11)
    axes[1].set_title("Mean freq_scale by head\n(>1=amplified, <1=suppressed)",
                       fontsize=12, color=CYAN)
    axes[1].legend(fontsize=9)
    axes[1].grid(True, alpha=0.3)

    patches = [
        mpatches.Patch(color=CYAN,  label=f"Local heads 0-{n_local-1}"),
        mpatches.Patch(color=GOLD,  label=f"Mid heads {n_local}-{n_local+n_mid-1}"),
        mpatches.Patch(color=PINK,  label=f"Long heads {n_local+n_mid}-{n_heads-1}"),
    ]
    axes[1].legend(handles=patches, fontsize=9)

    fig.suptitle(f"Learned Frequency Scaling — {pe_name}",
                 fontsize=13, color=WHITE)
    plt.tight_layout()
    _save(fig, out_path)


def plot_effective_frequencies(data: dict, out_path: str, pe_name: str) -> None:
    """
    Show the effective frequencies (base_freqs * freq_scale) per head.
    Compared to the original prime frequencies.
    """
    base = data["base_freqs"].numpy()   # (n_heads, rope_half)
    eff  = data["effective_freqs"].numpy()
    n_heads  = data["n_heads"]
    rope_half = base.shape[1]

    fig, axes = plt.subplots(2, 1, figsize=(12, 7))

    # Convert freqs to period lengths (1/f * 2π gives token period)
    base_periods = 2 * np.pi / (base + 1e-10)
    eff_periods  = 2 * np.pi / (eff  + 1e-10)

    for h in range(n_heads):
        alpha = 0.3 + 0.5 * (h / n_heads)
        axes[0].semilogy(base_periods[h], alpha=alpha, color=GRID, linewidth=0.8)
        axes[1].semilogy(eff_periods[h],  alpha=alpha, color=CYAN, linewidth=0.8)

    axes[0].set_title("Base prime periods (before training)", fontsize=11)
    axes[0].set_xlabel("Frequency dimension", fontsize=10)
    axes[0].set_ylabel("Token period (log)", fontsize=10)
    axes[0].grid(True, alpha=0.3)

    axes[1].set_title("Effective periods after training (base × freq_scale)",
                       fontsize=11, color=CYAN)
    axes[1].set_xlabel("Frequency dimension", fontsize=10)
    axes[1].set_ylabel("Token period (log)", fontsize=10)
    axes[1].grid(True, alpha=0.3)

    fig.suptitle(f"Prime PE Frequencies Before/After Training — {pe_name}",
                 fontsize=12, color=WHITE)
    plt.tight_layout()
    _save(fig, out_path)


def plot_falsification_convergence(
    histories: dict[str, dict],
    out_path: str,
) -> None:
    """
    Plot convergence for all falsification variants.
    Clearly shows which controls match prime PE and which diverge.
    """
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Colour map: prime PE is cyan, others are muted
    special = {"prime_tiered": (CYAN, 2.8, "-"),
               "alibi":        (PINK, 2.0, "--")}
    muted   = [PLOT_STYLE["grey"], GOLD, "#8be9fd", "#ff5555",
               "#50fa7b", "#bd93f9"]

    all_names = list(histories.keys())
    muted_idx = 0

    for name, hist in histories.items():
        steps = hist.get("steps", [])
        ppls  = hist.get("val_ppl", [])
        if not steps:
            continue
        if name in special:
            col, lw, ls = special[name]
        else:
            col = muted[muted_idx % len(muted)]
            lw, ls = 1.5, "-"
            muted_idx += 1

        from falsification.models import VARIANTS
        label = VARIANTS.get(name, name)
        axes[0].plot(steps, ppls, color=col, linewidth=lw,
                     linestyle=ls, label=label[:40], alpha=0.9)
        if ppls:
            axes[0].annotate(f"{ppls[-1]:.0f}",
                             xy=(steps[-1], ppls[-1]),
                             xytext=(steps[-1] * 1.02, ppls[-1]),
                             color=col, fontsize=7, va="center")

    axes[0].set_xlabel("Step", fontsize=11)
    axes[0].set_ylabel("Val PPL", fontsize=11)
    axes[0].set_title("Falsification Convergence", fontsize=12, color=CYAN)
    axes[0].legend(fontsize=7, loc="upper right")
    axes[0].grid(True, alpha=0.3)

    # Final PPL bar chart
    names  = [n for n in histories if histories[n].get("val_ppl")]
    finals = [histories[n]["val_ppl"][-1] for n in names]
    colours = [special.get(n, (muted[i % len(muted)], 1, "-"))[0]
               for i, n in enumerate(names)]

    axes[1].barh(range(len(names)), finals, color=colours, alpha=0.85)
    axes[1].set_yticks(range(len(names)))
    from falsification.models import VARIANTS
    axes[1].set_yticklabels(
        [VARIANTS.get(n, n)[:35] for n in names], fontsize=8)
    axes[1].set_xlabel("Final Val PPL (lower = better)", fontsize=11)
    axes[1].set_title("Final PPL — Falsification Suite", fontsize=12, color=CYAN)
    axes[1].grid(True, alpha=0.3, axis="x")
    for i, v in enumerate(finals):
        axes[1].text(v + 0.5, i, f"{v:.1f}", va="center", fontsize=8, color=WHITE)

    fig.suptitle("Prime PE Falsification — Does Prime Structure Matter?",
                 fontsize=13, color=GOLD)
    plt.tight_layout()
    _save(fig, out_path)
