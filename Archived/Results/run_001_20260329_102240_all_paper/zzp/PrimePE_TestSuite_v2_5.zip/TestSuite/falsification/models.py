# TestSuite/falsification/models.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. Control PE variants for falsification experiments.
#             Each variant isolates one property of prime PE to test whether
#             the prime arithmetic structure itself matters, or just having
#             diverse non-geometric frequencies.
# ──────────────────────────────────────────────────────────────────────────────
#
# THE FALSIFICATION QUESTION:
#   Is it prime structure specifically that helps, or just:
#   (a) non-geometric frequency diversity?
#   (b) tiered allocation (local/mid/long)?
#   (c) having a learnable freq_scale?
#
# VARIANTS:
#   geometric_rope       — baseline RoPE (base 10000)
#   alibi                — baseline ALiBi
#   prime_tiered         — the real thing (SpectralRoPEALiBi)
#   scrambled_prime      — same primes, shuffled across tiers randomly
#   random_freq          — random frequencies in same ranges, same tier structure
#   composite_only       — composites instead of primes (same ranges)
#   prime_alibi_noscale  — prime tiered but freq_scale frozen at 1.0 (no learning)
#   antiresonance        — frequencies chosen to minimise primorial resonance
# ──────────────────────────────────────────────────────────────────────────────

from __future__ import annotations
import math
import random
import sys
import os

import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from shared.primes import get_primes, spectral_rope_freqs, is_prime


# ── Frequency set builders ────────────────────────────────────────────────────

def _prime_freqs(d_model: int, n_heads: int) -> torch.Tensor:
    """Standard tiered prime frequencies."""
    return spectral_rope_freqs(d_model, n_heads)


def _scrambled_prime_freqs(d_model: int, n_heads: int, seed: int = 42) -> torch.Tensor:
    """
    Same prime set as tiered allocation, but randomly shuffled across heads.
    Tests: does the *structure* of tiered allocation matter,
    or just having prime frequencies?
    """
    base = spectral_rope_freqs(d_model, n_heads)  # (n_heads, rope_half)
    rng  = torch.Generator()
    rng.manual_seed(seed)
    idx  = torch.randperm(n_heads, generator=rng)
    return base[idx]


def _random_freq_tiered(d_model: int, n_heads: int, seed: int = 42) -> torch.Tensor:
    """
    Random frequencies in the same ranges as prime tiers, same tier structure.
    Tests: does prime structure matter, or just having diverse frequencies
    in the local/mid/long ranges?
    """
    rope_half = (d_model // n_heads) // 2
    n_local   = max(1, n_heads // 4)
    n_mid     = max(1, n_heads // 3)
    n_long    = max(1, n_heads - n_local - n_mid)

    ranges = (
        [(2, 101)]    * n_local +
        [(101, 1009)] * n_mid   +
        [(1009, 8209)]* n_long
    )

    rng = random.Random(seed)
    rows = []
    for p_min, p_max in ranges:
        freqs = sorted([rng.uniform(p_min, p_max) for _ in range(rope_half)])
        rows.append(torch.tensor([2 * math.pi / f for f in freqs],
                                  dtype=torch.float32))
    return torch.stack(rows)


def _composite_freqs(d_model: int, n_heads: int) -> torch.Tensor:
    """
    Composite numbers (non-primes) in the same ranges as prime tiers.
    Tests: does having primes specifically matter vs just non-geometric integers?
    The composites are the 'anti-primes' — divisible, not coprime with most things.
    """
    rope_half = (d_model // n_heads) // 2
    n_local   = max(1, n_heads // 4)
    n_mid     = max(1, n_heads // 3)
    n_long    = max(1, n_heads - n_local - n_mid)

    # (p_min, p_max, slots_per_head, n_heads_in_tier)
    tiers = [
        (2,    101,  max(4, rope_half // 4), n_local),
        (101,  1009, rope_half,              n_mid),
        (1009, 8209, rope_half,              n_long),
    ]

    def get_composites(lo: int, hi: int, n: int) -> list[int]:
        comps = [x for x in range(max(4, lo), hi) if not is_prime(x)]
        if len(comps) <= n:
            return comps
        step = len(comps) / n
        return [comps[int(i * step)] for i in range(n)]

    rows = []
    for p_min, p_max, slots, n_h in tiers:
        comps = get_composites(p_min, p_max, n_h * slots)
        for i in range(n_h):
            hc = comps[i * slots:(i + 1) * slots]
            while len(hc) < rope_half:
                hc = hc + hc
            hc = hc[:rope_half]
            rows.append(torch.tensor([2 * math.pi / c for c in hc],
                                      dtype=torch.float32))
    return torch.stack(rows)


def _antiresonance_freqs(d_model: int, n_heads: int) -> torch.Tensor:
    """
    Frequencies chosen to MINIMISE primorial resonance.
    Uses numbers between primorials rather than the primorials themselves.
    Tests: is the primorial anchor structure the active ingredient?
    This is the structural opposite of prime PE.
    """
    rope_half = (d_model // n_heads) // 2
    # Primorials: 2, 6, 30, 210, 2310 — we want numbers between them
    # and between consecutive primes (anti-cicada: maximally synced with everything)
    antis = []
    primes = get_primes(128)
    # Use midpoints between consecutive primes (maximally "average")
    for i in range(len(primes) - 1):
        mid = (primes[i] + primes[i + 1]) / 2.0
        antis.append(mid)

    rows = []
    n_per_tier = max(1, len(antis) // n_heads)
    for h in range(n_heads):
        start = h * n_per_tier
        hf = antis[start:start + rope_half]
        while len(hf) < rope_half:
            hf = hf + antis[:rope_half - len(hf)]
        rows.append(torch.tensor([2 * math.pi / f for f in hf[:rope_half]],
                                  dtype=torch.float32))
    return torch.stack(rows)


# ── Attention implementations ─────────────────────────────────────────────────

class _SpectralALiBiAttn(nn.Module):
    """Shared SpectralALiBi attention. head_freqs determines the variant."""

    def __init__(self, d_model: int, n_heads: int, dropout: float,
                 head_freqs: torch.Tensor, learn_scale: bool = True) -> None:
        super().__init__()
        self.n_heads  = n_heads
        self.head_dim = d_model // n_heads
        self.scale    = self.head_dim ** -0.5
        self.qkv  = nn.Linear(d_model, 3 * d_model, bias=False)
        self.proj = nn.Linear(d_model, d_model, bias=False)
        self.drop = nn.Dropout(dropout)
        self.register_buffer("head_freqs", head_freqs)
        self.freq_scale = (nn.Parameter(torch.ones(n_heads)) if learn_scale
                           else None)
        slopes = torch.tensor(
            [2 ** (-8 * (h + 1) / n_heads) for h in range(n_heads)],
            dtype=torch.float32)
        self.slopes = nn.Parameter(slopes)

    def _rope(self, x: torch.Tensor) -> torch.Tensor:
        B, H, T, D = x.shape
        t  = torch.arange(T, device=x.device, dtype=x.dtype)
        hf = self.head_freqs[:, :D // 2].to(x.dtype)
        if self.freq_scale is not None:
            hf = hf * self.freq_scale.abs().unsqueeze(1)
        ph = torch.einsum("t,hd->htd", t, hf)
        c, s = ph.cos().unsqueeze(0), ph.sin().unsqueeze(0)
        x1, x2 = x[..., 0::2], x[..., 1::2]
        return torch.stack([x1 * c - x2 * s, x1 * s + x2 * c], -1).flatten(-2)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape
        qkv = self.qkv(x).reshape(B, T, 3, self.n_heads, self.head_dim)
        q, k, v = qkv.permute(2, 0, 3, 1, 4).unbind(0)
        q, k   = self._rope(q), self._rope(k)
        sc     = (q @ k.transpose(-2, -1)) * self.scale
        pos    = torch.arange(T, device=x.device, dtype=x.dtype)
        dist   = (pos.unsqueeze(0) - pos.unsqueeze(1)).abs()
        alibi  = (-self.slopes.abs().view(1, self.n_heads, 1, 1)
                  * dist.unsqueeze(0).unsqueeze(0))
        causal = torch.triu(
            torch.full((T, T), float("-inf"), device=x.device,
                       dtype=sc.dtype), 1)
        w   = (sc + alibi + causal).softmax(-1)
        out = (self.drop(w) @ v).transpose(1, 2).reshape(B, T, C)
        return self.proj(out)


class _ALiBiAttn(nn.Module):
    def __init__(self, d_model: int, n_heads: int, dropout: float) -> None:
        super().__init__()
        self.n_heads  = n_heads
        self.head_dim = d_model // n_heads
        self.scale    = self.head_dim ** -0.5
        self.qkv  = nn.Linear(d_model, 3 * d_model, bias=False)
        self.proj = nn.Linear(d_model, d_model, bias=False)
        self.drop = nn.Dropout(dropout)
        slopes = torch.tensor(
            [2 ** (-8 * (h + 1) / n_heads) for h in range(n_heads)],
            dtype=torch.float32)
        self.register_buffer("slopes", slopes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape
        qkv = self.qkv(x).reshape(B, T, 3, self.n_heads, self.head_dim)
        q, k, v = qkv.permute(2, 0, 3, 1, 4).unbind(0)
        sc = (q @ k.transpose(-2, -1)) * self.scale
        pos = torch.arange(T, device=x.device, dtype=x.dtype)
        dist = (pos.unsqueeze(0) - pos.unsqueeze(1)).abs()
        alibi = (-self.slopes.view(1, self.n_heads, 1, 1)
                 * dist.unsqueeze(0).unsqueeze(0))
        causal = torch.triu(
            torch.full((T, T), float("-inf"), device=x.device,
                       dtype=sc.dtype), 1)
        w = (sc + alibi + causal).softmax(-1)
        return self.proj((self.drop(w) @ v).transpose(1, 2).reshape(B, T, C))


# ── Block ─────────────────────────────────────────────────────────────────────

class _Block(nn.Module):
    def __init__(self, d_model: int, ffn_dim: int, dropout: float,
                 attn: nn.Module) -> None:
        super().__init__()
        self.attn  = attn
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.ffn   = nn.Sequential(
            nn.Linear(d_model, ffn_dim), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(ffn_dim, d_model), nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.norm1(x))
        x = x + self.ffn(self.norm2(x))
        return x


# ── FalsificationModel ────────────────────────────────────────────────────────

class FalsificationModel(nn.Module):
    """
    Small transformer for falsification experiments.
    Supports all control variants. Memory-efficient for RTX 2060.
    """

    def __init__(self, cfg: dict, variant: str) -> None:
        super().__init__()
        d   = cfg["d_model"]
        nh  = cfg["n_heads"]
        nl  = cfg["n_layers"]
        ffn = cfg.get("ffn_dim", d * 4)
        dr  = cfg.get("dropout", 0.1)
        v   = cfg["vocab_size"]

        self.embed   = nn.Embedding(v, d)
        self.drop    = nn.Dropout(dr)
        self.norm    = nn.LayerNorm(d)
        self.lm_head = nn.Linear(d, v, bias=False)
        self.embed.weight = self.lm_head.weight
        self.variant = variant

        # Build attention factory based on variant
        def make_attn() -> nn.Module:
            if variant == "alibi":
                return _ALiBiAttn(d, nh, dr)
            elif variant == "geometric_rope":
                # Use standard ALiBi architecture but with geometric freqs
                geo = (1.0 / (10000 ** (torch.arange(0, d // nh, 2).float()
                                         / (d // nh))))
                geo = geo.unsqueeze(0).expand(nh, -1)
                return _SpectralALiBiAttn(d, nh, dr, geo, learn_scale=False)
            elif variant == "prime_tiered":
                hf = _prime_freqs(d, nh)
                return _SpectralALiBiAttn(d, nh, dr, hf, learn_scale=True)
            elif variant == "scrambled_prime":
                hf = _scrambled_prime_freqs(d, nh)
                return _SpectralALiBiAttn(d, nh, dr, hf, learn_scale=True)
            elif variant == "random_freq":
                hf = _random_freq_tiered(d, nh)
                return _SpectralALiBiAttn(d, nh, dr, hf, learn_scale=True)
            elif variant == "composite_only":
                hf = _composite_freqs(d, nh)
                return _SpectralALiBiAttn(d, nh, dr, hf, learn_scale=True)
            elif variant == "prime_noscale":
                hf = _prime_freqs(d, nh)
                return _SpectralALiBiAttn(d, nh, dr, hf, learn_scale=False)
            elif variant == "antiresonance":
                hf = _antiresonance_freqs(d, nh)
                return _SpectralALiBiAttn(d, nh, dr, hf, learn_scale=True)
            else:
                raise ValueError(f"Unknown falsification variant: {variant}")

        self.blocks = nn.ModuleList([
            _Block(d, ffn, dr, make_attn()) for _ in range(nl)
        ])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.drop(self.embed(x))
        for b in self.blocks:
            x = b(x)
        return self.lm_head(self.norm(x))


# ── Factory ───────────────────────────────────────────────────────────────────

# All falsification variants with their human-readable descriptions
VARIANTS = {
    "prime_tiered":    "SpectralALiBi (prime tiered + learnable scale) ← OURS",
    "alibi":           "ALiBi (standard, baseline)",
    "geometric_rope":  "GeometricRoPE+ALiBi (base-10000, frozen scale)",
    "scrambled_prime": "Scrambled primes (same set, random tier assignment)",
    "random_freq":     "Random frequencies (same ranges, no prime structure)",
    "composite_only":  "Composites only (anti-prime: highly divisible numbers)",
    "prime_noscale":   "Prime tiered (frozen freq_scale=1.0)",
    "antiresonance":   "Anti-resonance (frequencies between primes/primorials)",
}

# Shorter list for quick runs
VARIANTS_QUICK = [
    "prime_tiered",
    "alibi",
    "scrambled_prime",
    "random_freq",
    "composite_only",
]

def make_model(variant: str, cfg: dict) -> FalsificationModel:
    return FalsificationModel(cfg, variant)
