# TestSuite/falsification/train_eval.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. Training loop and PPL eval for falsification experiments.
# ──────────────────────────────────────────────────────────────────────────────

from __future__ import annotations
import gc
import logging
import math
import time

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader

log = logging.getLogger("primePE")


def train_parallel(
    models: dict[str, nn.Module],
    train_loader: DataLoader,
    val_loader: DataLoader,
    cfg: dict,
    device: str,
    dtype: torch.dtype,
) -> dict[str, dict]:
    """
    Train all falsification models in parallel on shared batches.
    Memory-efficient for RTX 2060: small models, grad accumulation.

    Returns:
        {variant: {"steps": [...], "val_ppl": [...], "train_loss": [...]}}
    """
    opts = {
        v: torch.optim.AdamW(m.parameters(),
                              lr=cfg["lr"], weight_decay=0.01)
        for v, m in models.items()
    }

    def lr_fn(step: int) -> float:
        w  = cfg["warmup_steps"]
        ms = cfg["max_steps"]
        if step < w:
            return step / max(w, 1)
        t = (step - w) / max(ms - w, 1)
        return 0.5 * (1 + math.cos(math.pi * t))

    scheds = {v: torch.optim.lr_scheduler.LambdaLR(opts[v], lr_fn)
              for v in models}

    history  = {v: {"steps": [], "val_ppl": [], "train_loss": []}
                for v in models}
    accum    = cfg.get("grad_accum", 8)
    scaler   = torch.cuda.amp.GradScaler() if device.startswith("cuda") else None
    step     = 0
    t_start  = time.time()
    dev_type = "cuda" if device.startswith("cuda") else "cpu"

    for m in models.values():
        m.train()

    data_iter = iter(train_loader)

    while step < cfg["max_steps"]:
        for m in models.values():
            opts[list(models.keys())[0]] # ensure same step alignment

        # Gradient accumulation
        for _ in range(accum):
            try:
                x, y = next(data_iter)
            except StopIteration:
                data_iter = iter(train_loader)
                x, y = next(data_iter)
            x, y = x.to(device), y.to(device)

            for v, model in models.items():
                with torch.autocast(device_type=dev_type, dtype=dtype):
                    logits = model(x)
                    loss   = F.cross_entropy(
                        logits.reshape(-1, cfg["vocab_size"]),
                        y.reshape(-1)) / accum
                if scaler:
                    scaler.scale(loss).backward()
                else:
                    loss.backward()

        for v, model in models.items():
            if scaler:
                scaler.unscale_(opts[v])
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            if scaler:
                scaler.step(opts[v])
            else:
                opts[v].step()
            opts[v].zero_grad()
            scheds[v].step()

        if scaler:
            scaler.update()

        step += 1

        # Evaluate
        if step % cfg["eval_every"] == 0 or step == cfg["max_steps"]:
            elapsed = time.time() - t_start
            log.info("Step %5d/%d | %.0fs elapsed",
                     step, cfg["max_steps"], elapsed)

            for v, model in models.items():
                model.eval()
                losses = []
                with torch.no_grad():
                    for i, (x, y) in enumerate(val_loader):
                        if i >= cfg.get("eval_batches", 40):
                            break
                        x, y = x.to(device), y.to(device)
                        with torch.autocast(device_type=dev_type, dtype=dtype):
                            logits = model(x)
                        losses.append(F.cross_entropy(
                            logits.reshape(-1, cfg["vocab_size"]),
                            y.reshape(-1)).item())
                ppl = math.exp(sum(losses) / max(len(losses), 1))
                history[v]["steps"].append(step)
                history[v]["val_ppl"].append(ppl)
                log.info("  %-36s ppl=%7.1f", v, ppl)
                model.train()

    return history


def eval_ppl_at_contexts(
    models: dict[str, nn.Module],
    ctx_lens: list[int],
    cache_dir: str,
    device: str,
    dtype: torch.dtype,
    n_batches: int = 60,
) -> dict[str, dict[int, float]]:
    """
    Evaluate each model at multiple context lengths.
    Loads tokenised data from cache (or generates it).
    """
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    from pe_eval.data import make_eval_loader

    results = {v: {} for v in models}
    dev_type = "cuda" if device.startswith("cuda") else "cpu"

    for ctx in ctx_lens:
        loader = make_eval_loader("test", ctx, cache_dir)
        log.info("Eval at ctx=%d...", ctx)
        for v, model in models.items():
            model.eval()
            losses = []
            with torch.no_grad():
                for i, (x, y) in enumerate(loader):
                    if i >= n_batches:
                        break
                    x, y = x.to(device), y.to(device)
                    with torch.autocast(device_type=dev_type, dtype=dtype):
                        logits = model(x)
                    losses.append(F.cross_entropy(
                        logits.reshape(-1, logits.size(-1)),
                        y.reshape(-1)).item())
            ppl = math.exp(sum(losses) / max(len(losses), 1))
            results[v][ctx] = round(ppl, 2)
            log.info("  %-36s ctx=%d ppl=%.1f", v, ctx, ppl)

    return results
