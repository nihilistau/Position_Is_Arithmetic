#!/usr/bin/env python3
# TestSuite/run_pe_eval.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. CLI entry point for PE checkpoint evaluation.
#             Loads one checkpoint at a time (RTX 2060 12GB safe).
#
# Usage:
#   python run_pe_eval.py                          # eval all checkpoints
#   python run_pe_eval.py --ckpt-dir C:\path\to\ckpts
#   python run_pe_eval.py --ctx 512 1024 2048 4096
#   python run_pe_eval.py --batches 40             # faster, less accurate
#   python run_pe_eval.py --train                  # also run mini training
# ──────────────────────────────────────────────────────────────────────────────

import argparse
import os
import sys
import time

import torch

# ── Path setup ────────────────────────────────────────────────────────────────
SUITE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SUITE_DIR)

from config import (PE_EVAL_CONFIG, MINI_TRAIN_CONFIG, DEVICE, DTYPE,
                    RESULTS_DIR, TOKEN_CACHE_DIR, CHECKPOINT_DIR)
from shared.utils import setup_run_dir, setup_logger, save_json, print_banner, gpu_info
from shared.plots import (plot_ppl_vs_context, plot_convergence,
                           plot_gap_analysis, plot_degradation_bar)
from pe_eval.eval import (run_degradation_table, compile_degradation_results,
                           print_degradation_report)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="PrimePE — PE Evaluation Test Suite",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument(
        "--ckpt-dir", type=str, default=CHECKPOINT_DIR,
        help=f"Directory containing checkpoint .pt files (default: config.CHECKPOINT_DIR)"
    )
    p.add_argument(
        "--ctx", nargs="+", type=int,
        default=PE_EVAL_CONFIG["eval_ctx_lens"],
        help="Context lengths to evaluate (default: 512 1024 2048 4096 8192)"
    )
    p.add_argument(
        "--batches", type=int, default=PE_EVAL_CONFIG["eval_batches"],
        help=f"Eval batches per context length (default: {PE_EVAL_CONFIG['eval_batches']})"
    )
    p.add_argument(
        "--train", action="store_true",
        help="Also run mini training experiment from scratch (T4 profile)"
    )
    p.add_argument(
        "--train-steps", type=int, default=MINI_TRAIN_CONFIG["max_steps"],
        help=f"Steps for mini training (default: {MINI_TRAIN_CONFIG['max_steps']})"
    )
    return p.parse_args()


def run_mini_train(cfg: dict, pe_dir: str, log) -> dict:
    """
    Run a small training experiment from scratch.
    Uses T4 profile: d=256, 6L, 8H, ctx=1024.
    Returns training history.
    """
    from pe_eval.data import make_eval_loader, tokenise_wikitext, ChunkDataset
    from pe_eval.models import PrimePEModel
    from torch.utils.data import DataLoader
    import torch.nn.functional as F
    import math, gc

    log.info("Mini training: %d steps, d=%d, ctx=%d",
             cfg["max_steps"], cfg["d_model"], cfg["train_seq_len"])

    # Build models
    models = {}
    for pe in cfg["variants"]:
        m = PrimePEModel(cfg, pe).to(DEVICE)
        n = sum(p.numel() for p in m.parameters())
        log.info("  %-26s %d params", pe, n)
        models[pe] = m

    # Optimisers
    opts = {
        pe: torch.optim.AdamW(m.parameters(), lr=cfg["lr"],
                               weight_decay=0.01)
        for pe, m in models.items()
    }

    # Data
    from config import TOKEN_CACHE_DIR
    chunks_train = tokenise_wikitext("train",      cfg["train_seq_len"], TOKEN_CACHE_DIR)
    chunks_val   = tokenise_wikitext("validation", cfg["train_seq_len"], TOKEN_CACHE_DIR)
    train_ds     = ChunkDataset(chunks_train)
    val_ds       = ChunkDataset(chunks_val)
    train_loader = DataLoader(train_ds, batch_size=cfg["batch_size"],
                              shuffle=True, num_workers=0, drop_last=True)
    val_loader   = DataLoader(val_ds, batch_size=1,
                              shuffle=False, num_workers=0, drop_last=True)

    history = {pe: {"steps": [], "val_ppl": []} for pe in models}

    # Warmup + cosine schedule
    def lr_fn(step: int) -> float:
        w = cfg["warmup_steps"]
        ms = cfg["max_steps"]
        if step < w:
            return step / max(w, 1)
        t = (step - w) / max(ms - w, 1)
        return 0.5 * (1 + math.cos(math.pi * t))

    schedulers = {
        pe: torch.optim.lr_scheduler.LambdaLR(opts[pe], lr_fn)
        for pe in models
    }

    scaler    = torch.cuda.amp.GradScaler()
    accum     = cfg["grad_accum"]
    step      = 0
    t_start   = time.time()

    for pe in models.values():
        pe.train()

    data_iter = iter(train_loader)

    while step < cfg["max_steps"]:
        # Accumulate gradients
        for pe in models.values():
            opts[models_to_opts[pe]] if False else None  # placeholder

        for _ in range(accum):
            try:
                x, y = next(data_iter)
            except StopIteration:
                data_iter = iter(train_loader)
                x, y = next(data_iter)
            x, y = x.to(DEVICE), y.to(DEVICE)

            for pe, model in models.items():
                device_type = "cuda" if DEVICE.startswith("cuda") else "cpu"
                with torch.autocast(device_type=device_type, dtype=DTYPE):
                    logits = model(x)
                    loss   = F.cross_entropy(
                        logits.reshape(-1, cfg["vocab_size"]), y.reshape(-1)
                    ) / accum
                scaler.scale(loss).backward()

        for pe, model in models.items():
            scaler.unscale_(opts[pe])
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler.step(opts[pe])
            scaler.update()
            opts[pe].zero_grad()
            schedulers[pe].step()

        step += 1

        # Eval
        if step % cfg["eval_every"] == 0 or step == cfg["max_steps"]:
            log.info("Step %5d | lr=%.2e | %.0fs",
                     step,
                     opts[list(models.keys())[0]].param_groups[0]["lr"],
                     time.time() - t_start)
            for pe, model in models.items():
                model.eval()
                losses = []
                with torch.no_grad():
                    for i, (x, y) in enumerate(val_loader):
                        if i >= 40:
                            break
                        x, y = x.to(DEVICE), y.to(DEVICE)
                        device_type = "cuda" if DEVICE.startswith("cuda") else "cpu"
                        with torch.autocast(device_type=device_type, dtype=DTYPE):
                            logits = model(x)
                        losses.append(
                            F.cross_entropy(
                                logits.reshape(-1, cfg["vocab_size"]),
                                y.reshape(-1)
                            ).item()
                        )
                ppl = math.exp(sum(losses) / max(len(losses), 1))
                history[pe]["steps"].append(step)
                history[pe]["val_ppl"].append(ppl)
                log.info("  %-26s ppl=%.1f", pe, ppl)
                model.train()

    # Save checkpoints
    for pe, model in models.items():
        ckpt = os.path.join(pe_dir, f"mini_ckpt_{pe}.pt")
        torch.save(model.state_dict(), ckpt)
        log.info("Mini ckpt saved: %s", ckpt)

    del models, opts, schedulers
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    return history


def main() -> None:
    args = parse_args()

    # ── Setup run directory ───────────────────────────────────────────────────
    run_dir = setup_run_dir(RESULTS_DIR, prefix="pe_eval")
    pe_dir  = os.path.join(run_dir, "pe_eval")
    os.makedirs(pe_dir, exist_ok=True)

    log = setup_logger(run_dir, "primePE.pe_eval")

    print_banner("PE EVALUATION — PrimePE TestSuite")
    log.info("Run directory: %s", run_dir)
    log.info("Device: %s | GPU: %s", DEVICE, gpu_info())
    log.info("Checkpoint dir: %s", args.ckpt_dir)
    log.info("Context lengths: %s", args.ctx)

    # ── Checkpoint evaluation ─────────────────────────────────────────────────
    print_banner("Checkpoint Evaluation")

    cfg = PE_EVAL_CONFIG["model_cfg"]
    ppl_results = run_degradation_table(
        checkpoint_dir = args.ckpt_dir,
        ckpt_to_pe     = PE_EVAL_CONFIG["ckpt_to_pe"],
        cfg            = cfg,
        eval_ctx_lens  = sorted(args.ctx),
        cache_dir      = TOKEN_CACHE_DIR,
        device         = DEVICE,
        dtype          = DTYPE,
        n_batches      = args.batches,
    )

    if not ppl_results:
        log.warning("No checkpoints found in %s", args.ckpt_dir)
        log.warning("Edit config.py CHECKPOINT_DIR or pass --ckpt-dir")
    else:
        # Compile and save
        deg_results = compile_degradation_results(
            ppl_results, cfg, args.ckpt_dir)
        save_json(deg_results, os.path.join(pe_dir, "degradation_results.json"))
        save_json(ppl_results, os.path.join(pe_dir, "ppl_results.json"))

        # Print report
        print_degradation_report(deg_results)

        # Plots
        print_banner("Generating Plots")
        plot_ppl_vs_context(
            ppl_results,
            os.path.join(pe_dir, "ppl_vs_context.png"),
            train_ctx=cfg.get("train_seq_len"),
        )
        log.info("ppl_vs_context.png saved.")

        plot_degradation_bar(
            ppl_results,
            os.path.join(pe_dir, "degradation_bar.png"),
        )
        log.info("degradation_bar.png saved.")

    # ── Optional mini training ────────────────────────────────────────────────
    if args.train:
        print_banner("Mini Training (from scratch)")
        mini_cfg = dict(MINI_TRAIN_CONFIG)
        mini_cfg["max_steps"] = args.train_steps

        history = run_mini_train(mini_cfg, pe_dir, log)
        save_json(history, os.path.join(pe_dir, "mini_training_history.json"))

        plot_convergence(
            history,
            os.path.join(pe_dir, "mini_convergence.png"),
        )
        log.info("mini_convergence.png saved.")

        plot_gap_analysis(
            history,
            os.path.join(pe_dir, "mini_gap_analysis.png"),
        )
        log.info("mini_gap_analysis.png saved.")

    # ── Summary ───────────────────────────────────────────────────────────────
    print()
    log.info("All results saved to: %s", pe_dir)
    log.info("Key files:")
    log.info("  degradation_results.json — full degradation table")
    log.info("  ppl_results.json         — raw PPL numbers")
    log.info("  ppl_vs_context.png       — PPL vs context length plot")
    log.info("  degradation_bar.png      — bar chart by context length")
    if args.train:
        log.info("  mini_training_history.json — mini training history")
        log.info("  mini_convergence.png       — mini training curves")
        log.info("  mini_gap_analysis.png      — advantage gap over steps")


if __name__ == "__main__":
    main()
