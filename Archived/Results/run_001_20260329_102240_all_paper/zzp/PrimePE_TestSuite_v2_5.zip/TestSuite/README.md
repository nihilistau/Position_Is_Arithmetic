# PrimePE TestSuite v2.0.0
# Author: Knack | 2026-03-29

## Overview

Complete local test suite for Prime-Harmonic Positional Encoding.
Designed for RTX 2060 12GB (local fast runs) and RunPod A100/H100 (full scale).

## Structure

```
TestSuite/
  run_zzp.py              ← ZetaZeroPredictor (RTX 2060, ~5-10 min)
  run_pe_eval.py          ← Checkpoint eval + optional mini training
  run_falsification.py    ← Designed to disprove the theory (RTX 2060, ~30 min)
  run_freq_analysis.py    ← What did the model learn? freq_scale + LLL
  config.py               ← Edit CHECKPOINT_DIR here

  falsification/          ← 8 control variants: scrambled, random, composite...
  freq_analysis/          ← freq_scale extraction, LLL weight matrix analysis
  runpod/                 ← setup.sh + launch_g4.py for full-scale runs
  shared/                 ← utils, plots, primes
  zzp/                    ← ZetaZeroPredictor
  pe_eval/                ← PE eval and training
  results/                ← Auto-created run directories
```

## Quick Start (RTX 2060)

```bash
# Edit config.py first: set CHECKPOINT_DIR

# ZZP (~5 min)
python run_zzp.py --epochs 400

# Falsification (~30 min) 
python run_falsification.py --steps 3000

# Checkpoint evaluation
python run_pe_eval.py

# What did the model learn?
python run_freq_analysis.py --skip-lll
```

## Falsification Tests

| Variant | Question |
|---------|---------|
| scrambled_prime | Tier ordering or just prime diversity? |
| random_freq | Primes specifically or any diverse freqs? |
| composite_only | Prime multiplicative structure or any integers? |
| prime_noscale | Does learned freq_scale matter? |
| antiresonance | Does primorial resonance structure matter? |

## RunPod

```bash
# In RunPod terminal after uploading zip:
bash TestSuite/runpod/setup.sh
python runpod/launch_g4.py --steps 20000
```

## Hardware

RTX 2060 12GB: ZZP <10min, Falsification ~30min, PE eval ~45min
RunPod A100 80GB: Full G4 20K steps ~4-6 hrs (~$10-16 spot)
