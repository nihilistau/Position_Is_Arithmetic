#!/usr/bin/env python3
# TestSuite/run_freq_analysis.py
# Version: v1.0.0 | Author: Knack | 2026-03-29
# Change Log:
#   v1.0.0 — Initial. Analyse what the model learned: freq_scale values
#             and LLL alignment of weight matrices.
#
# WHAT THIS ANSWERS:
#   1. freq_scale: What frequency basis did the model discover?
#      - Did long-range heads get suppressed? (expected at 4K training context)
#      - Which tiers did the model weight most heavily?
#      - Is freq_scale uniform (no preference) or structured?
#
#   2. LLL alignment: Is the model computing in the prime lattice?
#      - Do LLL-reduced W_Q/W_K vectors align with prime frequency directions?
#      - Better than a random matrix? (random = no alignment)
#      - Better in SpectralALiBi than in geometric RoPE? (the control)
#
# Usage:
#   python run_freq_analysis.py                          # all checkpoints in config
#   python run_freq_analysis.py --ckpt-dir C:\path\to\ckpts
#   python run_freq_analysis.py --skip-lll              # freq_scale only (fast)
# ──────────────────────────────────────────────────────────────────────────────

import argparse
import os
import sys

SUITE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SUITE_DIR)

from config import PE_EVAL_CONFIG, CHECKPOINT_DIR, RESULTS_DIR, DEVICE
from shared.utils import setup_run_dir, setup_logger, save_json, print_banner, gpu_info


def parse_args():
    p = argparse.ArgumentParser(description="PrimePE Freq/LLL Analysis")
    p.add_argument("--ckpt-dir", default=CHECKPOINT_DIR)
    p.add_argument("--skip-lll", action="store_true",
                   help="Skip LLL analysis (runs faster, less informative)")
    return p.parse_args()


def main():
    args = parse_args()

    run_dir  = setup_run_dir(RESULTS_DIR, prefix="freq_analysis")
    fa_dir   = os.path.join(run_dir, "freq_analysis")
    os.makedirs(fa_dir, exist_ok=True)

    log = setup_logger(run_dir, "primePE.freq_analysis")

    print_banner("FREQ SCALE + LLL ANALYSIS — PrimePE TestSuite")
    log.info("Run dir: %s", run_dir)
    log.info("Checkpoint dir: %s", args.ckpt_dir)

    cfg = PE_EVAL_CONFIG["model_cfg"]
    ckpt_map = PE_EVAL_CONFIG["ckpt_to_pe"]
    spectral_variants = ["spectral_rope_alibi", "spectral_rope",
                         "harmonic_string_alibi"]

    from freq_analysis.extract import extract_freq_scale, analyse_freq_scale, print_freq_report
    from freq_analysis.plots import plot_freq_scale_heatmap, plot_effective_frequencies

    all_freq_data = {}

    # ── Freq scale analysis ───────────────────────────────────────────────────
    print_banner("Freq Scale Analysis")
    for ckpt_stem, pe_name in ckpt_map.items():
        if pe_name not in spectral_variants:
            continue
        ckpt_path = os.path.join(args.ckpt_dir, f"{ckpt_stem}.pt")
        if not os.path.exists(ckpt_path):
            log.warning("Checkpoint not found: %s", ckpt_path)
            continue

        log.info("Analysing freq_scale: %s", pe_name)
        data = extract_freq_scale(ckpt_path, pe_name, cfg, device="cpu")
        if not data:
            continue

        analysis = analyse_freq_scale(data)
        print_freq_report(analysis, pe_name)

        # Save
        save_json({k: v.tolist() if hasattr(v, "tolist") else v
                   for k, v in {**analysis,
                                 "freq_scale_mean": data["freq_scale_mean"],
                                 "freq_scale_std":  data["freq_scale_std"]}.items()},
                  os.path.join(fa_dir, f"freq_scale_{pe_name}.json"))

        # Plots
        plot_freq_scale_heatmap(
            data, os.path.join(fa_dir, f"freq_heatmap_{pe_name}.png"), pe_name)
        plot_effective_frequencies(
            data, os.path.join(fa_dir, f"freq_effective_{pe_name}.png"), pe_name)
        log.info("Freq scale plots saved for %s.", pe_name)

        all_freq_data[pe_name] = analysis

    save_json(all_freq_data, os.path.join(fa_dir, "freq_scale_summary.json"))

    # ── LLL analysis ──────────────────────────────────────────────────────────
    if not args.skip_lll:
        print_banner("LLL Weight Matrix Analysis")
        log.info("This tests whether W_Q/W_K align with prime lattice directions.")
        log.info("Takes 2-5 minutes. Use --skip-lll to skip.")

        from freq_analysis.lll import run_lll_analysis, print_lll_report

        # Analyse spectral and geometric for comparison
        ckpts_for_lll = {}
        for ckpt_stem, pe_name in ckpt_map.items():
            ckpt_path = os.path.join(args.ckpt_dir, f"{ckpt_stem}.pt")
            if os.path.exists(ckpt_path):
                ckpts_for_lll[pe_name] = ckpt_path

        lll_results = run_lll_analysis(ckpts_for_lll, cfg, device="cpu")
        print_lll_report(lll_results)
        save_json({k: v for k, v in lll_results.items()},
                  os.path.join(fa_dir, "lll_results.json"))

    print()
    log.info("All analysis saved to: %s", fa_dir)
    log.info("Key files:")
    log.info("  freq_scale_summary.json    — tier breakdown of learned scales")
    log.info("  freq_heatmap_*.png         — layer/head heatmaps")
    log.info("  freq_effective_*.png       — learned vs base frequencies")
    if not args.skip_lll:
        log.info("  lll_results.json           — LLL alignment test results")


if __name__ == "__main__":
    main()
